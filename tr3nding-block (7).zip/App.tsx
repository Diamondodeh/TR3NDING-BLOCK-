
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { Home, Search, LayoutGrid, Download as DownloadIcon, User as UserIcon, Play, Star, ChevronRight, Settings, LogOut, ChevronLeft, Filter, Upload, Shield, X, HardDrive, Check, Menu, Trash2, UserPlus, Timer, LogIn, FolderSync, PlusCircle, Film, Tv, Zap, ChevronDown, Share2, AlertCircle, Loader2, Heart, MessageSquare, Info, Calendar, Clock, Volume2, Maximize, Pause, Server, ListPlus, Eye, HelpCircle, Flame, FileVideo, Globe, Bell, Scan, Languages, CircleHelp, Camera, Key, Mail, UserCheck, Circle } from 'lucide-react';
import { Movie, User, Download, LocalFile, Category, Episode, CloudConfig } from './types';
import { INITIAL_MOVIES, GENRES, YEARS, QUALITIES } from './constants';
import AuthService from './services/auth';
import LocalStorageService from './services/db';
import MediaPlayer from './components/MediaPlayer';
import AdminPanel from './components/AdminPanel';
import AdBlock from './components/AdBlock';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'home' | 'categories' | 'downloads' | 'profile' | 'admin' | 'view-all'>('home');
  const [viewAllConfig, setViewAllConfig] = useState<{ title: string, items: Movie[] } | null>(null);
  const [assetTab, setAssetTab] = useState<'queue' | 'library' | 'favorites' | 'local'>('library');
  const [currentUser, setCurrentUser] = useState<User | null>(AuthService.getCurrentUser());
  const [movies, setMovies] = useState<Movie[]>(INITIAL_MOVIES);
  const [downloads, setDownloads] = useState<Download[]>(LocalStorageService.getDownloads());
  const [localFiles, setLocalFiles] = useState<LocalFile[]>(LocalStorageService.getLocalFiles());
  const [cloudConfig, setCloudConfig] = useState<CloudConfig>(LocalStorageService.getCloudConfig());
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<Category | 'All'>('All');
  
  const [selectedMovie, setSelectedMovie] = useState<Movie | null>(null);
  const [playingMovie, setPlayingMovie] = useState<{title: string, videoUrl: string} | null>(null);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [settingsData, setSettingsData] = useState<Partial<User>>({});
  
  const [showAdOverlay, setShowAdOverlay] = useState(false);
  const [adCountdown, setAdCountdown] = useState(0);
  const [adMessage, setAdMessage] = useState('');
  const [isDecrypting, setIsDecrypting] = useState(false);

  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [authEmail, setAuthEmail] = useState('');
  const [authName, setAuthName] = useState('');
  const [longPressedFile, setLongPressedFile] = useState<LocalFile | null>(null);
  const longPressTimer = useRef<number | null>(null);
  const [movieToDownload, setMovieToDownload] = useState<Movie | null>(null);
  const [selectedEpisode, setSelectedEpisode] = useState<Episode | null>(null);
  const [selectedQuality, setSelectedQuality] = useState('360P');
  const localFileInputRef = useRef<HTMLInputElement>(null);
  const avatarInputRef = useRef<HTMLInputElement>(null);

  const filteredMovies = useMemo(() => {
    return movies.filter(movie => {
      const matchesSearch = movie.title.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = selectedCategory === 'All' || movie.category === selectedCategory;
      return matchesSearch && matchesCategory;
    });
  }, [movies, searchQuery, selectedCategory]);

  const todaysPick = useMemo(() => movies.find(m => m.isTrending) || movies[0], [movies]);

  const toggleFavorite = (id: string) => {
    if (!currentUser) return;
    const favorites = currentUser.favorites || [];
    const newFavs = favorites.includes(id) ? favorites.filter(fid => fid !== id) : [...favorites, id];
    const updatedUser = { ...currentUser, favorites: newFavs };
    setCurrentUser(updatedUser);
    localStorage.setItem('tr3nding_block_current_user', JSON.stringify(updatedUser));
  };

  const handlePlayMaster = (movie: Movie) => {
    setIsDecrypting(true);
    setAdMessage(cloudConfig.isConnected ? `Fetching Signed URL from ${cloudConfig.bucketName}...` : "Initializing Remote Stream...");
    setTimeout(() => {
      setIsDecrypting(false);
      // In a real app, you would fetch a temporary URL from your backend here
      setPlayingMovie({ title: movie.title, videoUrl: movie.videoUrl });
    }, 3000);
  };

  const initiateDownloadFlow = (movie: Movie, quality?: string) => {
    if (quality) setSelectedQuality(quality);
    setMovieToDownload(movie);
    if (movie.category === 'Series' && movie.episodes && movie.episodes.length > 0) {
      setSelectedEpisode(movie.episodes[0]);
    } else {
      setSelectedEpisode(null);
    }
  };

  const confirmDownload = (qualityOverride?: string) => {
    if (!movieToDownload) return;
    
    const targetQuality = qualityOverride || selectedQuality;
    const isHighQuality = ['720P', '1080P', '4K'].includes(targetQuality);
    const waitTime = isHighQuality ? 10 : 3;

    setAdMessage(isHighQuality ? "Verifying High-Bitrate Master..." : "Optimizing Asset Access...");
    setAdCountdown(waitTime);
    setShowAdOverlay(true);
    
    const movieRef = movieToDownload;
    const qualityRef = targetQuality;
    const episodeRef = selectedEpisode || undefined;
    
    setMovieToDownload(null);
    setSelectedEpisode(null);

    const timer = setInterval(() => {
      setAdCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          setShowAdOverlay(false);
          triggerDownloadProcess(movieRef, qualityRef, episodeRef);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const triggerDownloadProcess = (movie: Movie, quality: string, targetEpisode?: Episode) => {
    const sizeMap: Record<string, string> = { '360P': '223.8 MB', '480P': '661.7 MB', '720P': '1.1 GB', '1080P': '1.6 GB' };
    const epTitle = targetEpisode ? `S0${targetEpisode.season} E0${targetEpisode.id} · ${targetEpisode.title}` : movie.title;
    const size = targetEpisode?.size || sizeMap[quality] || '1.6 GB';

    const newDownload: Download = {
      id: Date.now().toString(),
      movieId: movie.id,
      title: `${epTitle} (${quality})`,
      thumbnail: movie.thumbnail,
      progress: 0,
      status: 'downloading',
      size: size
    };
    setDownloads(prev => [...prev, newDownload]);
    LocalStorageService.saveDownload(newDownload);
    
    let prog = 0;
    const interval = setInterval(() => {
      prog += Math.random() * 8;
      if (prog >= 100) {
        prog = 100;
        clearInterval(interval);
        setDownloads(dls => dls.map(d => d.id === newDownload.id ? { ...d, progress: 100, status: 'completed' } : d));
        LocalStorageService.addLocalFile({ id: Date.now().toString(), name: `${newDownload.title}.mp4`, url: targetEpisode?.videoUrl || movie.videoUrl, size: 2400000000, type: 'video/mp4' });
        setLocalFiles(LocalStorageService.getLocalFiles());
      } else {
        setDownloads(dls => dls.map(d => d.id === newDownload.id ? { ...d, progress: prog } : d));
      }
    }, 1000);
  };

  const handlePlayLocalFile = (file: LocalFile) => {
    setIsDecrypting(true);
    setAdMessage("Decrypting Local Master...");
    setTimeout(() => {
      setIsDecrypting(false);
      setPlayingMovie({ title: file.name, videoUrl: file.url });
    }, 2000);
  };

  const handlePickLocalVideos = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files) {
      Array.from(files).forEach((file: File) => {
        const url = URL.createObjectURL(file);
        const newFile: LocalFile = {
          id: Math.random().toString(36).substr(2, 9),
          name: file.name,
          url: url,
          size: file.size,
          type: file.type,
          lastModified: file.lastModified
        };
        LocalStorageService.addLocalFile(newFile);
      });
      setLocalFiles(LocalStorageService.getLocalFiles());
    }
  };

  const handleLogout = () => {
    AuthService.logout();
    setCurrentUser(null);
    setActiveTab('home');
    setIsSettingsOpen(false);
  };

  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSettingsData(prev => ({ ...prev, avatar: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveSettings = () => {
    if (!currentUser) return;
    const updatedUser = { ...currentUser, ...settingsData };
    AuthService.updateUser(updatedUser as User);
    setCurrentUser(updatedUser as User);
    setIsSettingsOpen(false);
  };

  const openSettings = () => {
    if (!currentUser) return;
    setSettingsData({
      name: currentUser.name,
      username: currentUser.username || currentUser.email,
      email: currentUser.email,
      phone: currentUser.phone || '',
      passwordSet: currentUser.passwordSet || false,
      avatar: currentUser.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${currentUser.name}`
    });
    setIsSettingsOpen(true);
  };

  const handleAuth = () => {
    if (authMode === 'login') {
      const u = AuthService.login(authEmail);
      if (u) {
        setCurrentUser(u);
        setActiveTab('home');
      } else {
        alert("Identity not found in archives.");
      }
    } else {
      if (!authName || !authEmail) return alert("Please fill all protocols.");
      const { user, error } = AuthService.register(authName, authEmail);
      if (user) {
        setCurrentUser(user);
        setActiveTab('home');
      } else {
        alert(error);
      }
    }
  };

  const openViewAll = (title: string, items: Movie[]) => {
    setViewAllConfig({ title, items });
    setActiveTab('view-all');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const renderMovieCard = (movie: Movie) => (
    <div key={movie.id} className="group relative flex-shrink-0 w-40 sm:w-48 lg:w-56">
      <div className="relative aspect-[2/3] rounded-[1.5rem] overflow-hidden border border-white/5 transition-all group-hover:border-gold group-hover:scale-[1.05] shadow-2xl cursor-pointer">
        <img src={movie.thumbnail} className="w-full h-full object-cover transition-transform group-hover:scale-110 duration-700" alt={movie.title} />
        <div className="absolute inset-0 z-10" onClick={() => setSelectedMovie(movie)} />
        <div className="absolute top-2 left-2 bg-gold/90 text-black text-[7px] font-black px-1.5 py-0.5 rounded tracking-tighter shadow-lg z-20">4K</div>
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity z-0" />
        <button 
          onClick={(e) => { e.stopPropagation(); initiateDownloadFlow(movie); }}
          className="absolute bottom-3 right-3 p-2.5 bg-black/60 backdrop-blur-xl border border-gold/40 rounded-xl text-gold opacity-0 group-hover:opacity-100 transition-all hover:bg-gold hover:text-black shadow-xl z-20 scale-90 group-hover:scale-100"
        >
          <DownloadIcon className="w-4 h-4" />
        </button>
      </div>

      <div className="mt-3 px-1">
        <h3 className="text-[10px] font-black uppercase text-gray-300 tracking-wider truncate mb-1 group-hover:text-gold transition-colors">{movie.title}</h3>
        <div className="flex justify-between items-center opacity-60">
          <span className="text-[8px] text-gray-500 font-bold uppercase">{movie.year}</span>
          <div className="flex items-center gap-1"><Star className="w-2.5 h-2.5 text-gold fill-gold" /><span className="text-[8px] font-black text-gray-400">{movie.rating}</span></div>
        </div>
      </div>
    </div>
  );

  const renderSection = (title: string, items: Movie[], icon: React.ReactNode) => {
    if (items.length === 0) return null;
    return (
      <section className="mb-12">
        <div className="flex justify-between items-end mb-6 px-6">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-gold/10 rounded-lg text-gold">{icon}</div>
            <h2 className="text-xl font-luxury font-bold text-white uppercase tracking-tighter">{title}</h2>
          </div>
          <button 
            onClick={() => openViewAll(title, items)}
            className="text-[9px] font-black text-gray-500 hover:text-gold transition-colors uppercase tracking-[0.2em]"
          >
            View All
          </button>
        </div>
        <div className="flex gap-6 overflow-x-auto no-scrollbar px-6 pb-4">
          {items.map(renderMovieCard)}
        </div>
      </section>
    );
  };

  const renderHome = () => {
    const moviesOnly = movies.filter(m => m.category === 'Movie');
    const seriesOnly = movies.filter(m => m.category === 'Series');
    const animeOnly = movies.filter(m => m.category === 'Anime');
    const others = movies.filter(m => !['Movie', 'Series', 'Anime'].includes(m.category));

    return (
      <div className="pb-24 animate-in fade-in duration-500">
        {todaysPick && (
          <div className="relative w-full aspect-[16/10] sm:aspect-[21/9] mb-12 overflow-hidden px-6">
             <div className="w-full h-full rounded-[2.5rem] overflow-hidden relative border border-gold/10 group shadow-2xl">
                <img src={todaysPick.thumbnail} className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105" alt="" />
                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent" />
                <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-transparent to-transparent" />
                <div className="absolute inset-0 flex flex-col justify-end p-8 sm:p-12 md:p-16">
                   <div className="flex items-center gap-2 mb-4 bg-gold/90 text-black px-3 py-1 w-fit rounded-full text-[9px] font-black uppercase tracking-widest shadow-xl">
                      <Flame className="w-3 h-3" /> Today's Pick
                   </div>
                   <h1 className="text-3xl sm:text-4xl md:text-5xl font-luxury font-bold text-white uppercase tracking-tighter mb-4 max-w-2xl">{todaysPick.title}</h1>
                   <p className="text-[10px] sm:text-xs text-gray-300 font-medium max-w-md line-clamp-2 mb-8 uppercase tracking-widest leading-relaxed opacity-80">{todaysPick.description}</p>
                   <div className="flex gap-4">
                      <button onClick={() => handlePlayMaster(todaysPick)} className="flex items-center gap-3 bg-gold text-black px-8 py-4 rounded-2xl font-black text-xs uppercase tracking-widest shadow-2xl shadow-gold/20 hover:scale-105 active:scale-95 transition-all">
                        <Play className="w-5 h-5 fill-current" /> Watch Now
                      </button>
                      <button onClick={() => setSelectedMovie(todaysPick)} className="flex items-center gap-3 bg-white/10 backdrop-blur-xl border border-white/10 text-white px-8 py-4 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-white/20 transition-all">
                        <Info className="w-5 h-5" /> Details
                      </button>
                   </div>
                </div>
             </div>
          </div>
        )}

        <div className="px-6 pt-4 mb-8">
           <div className="relative group max-w-2xl mx-auto">
              <Search className="absolute left-6 top-1/2 -translate-y-1/2 w-4 h-4 text-gold" />
              <input 
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Search Categories..." 
                className="w-full bg-charcoal/50 border border-white/5 rounded-2xl py-5 pl-14 pr-6 font-black uppercase text-[10px] tracking-widest text-white focus:outline-none focus:border-gold/30 transition-all placeholder:text-gray-700"
              />
           </div>
        </div>

        {searchQuery ? (
          <div className="px-6 max-w-7xl mx-auto">
            <h2 className="text-xl font-luxury font-bold text-white uppercase tracking-tighter mb-8">Search Results</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-6">
              {filteredMovies.map(renderMovieCard)}
            </div>
          </div>
        ) : (
          <>
            {renderSection("Master Movies", moviesOnly, <Film className="w-5 h-5" />)}
            <AdBlock variant="reduced" format="rectangle" className="opacity-90 mb-12" />
            
            {renderSection("Global Series", seriesOnly, <Tv className="w-5 h-5" />)}
            {renderSection("Anime Hub", animeOnly, <Zap className="w-5 h-5" />)}
            {renderSection("Others", others, <LayoutGrid className="w-5 h-5" />)}
            
            <AdBlock variant="reduced" format="rectangle" className="opacity-80 mb-12" />
          </>
        )}
      </div>
    );
  };

  const renderViewAll = () => {
    if (!viewAllConfig) return null;
    return (
      <div className="pb-24 animate-in fade-in duration-500 px-6 pt-6">
        <div className="flex items-center gap-4 mb-8">
           <button onClick={() => { setActiveTab('home'); setViewAllConfig(null); }} className="p-3 bg-white/5 rounded-2xl border border-white/10 text-white active:scale-90 transition-all">
              <ChevronLeft className="w-6 h-6" />
           </button>
           <h1 className="text-3xl font-luxury font-bold gold-text-gradient uppercase tracking-tighter">{viewAllConfig.title}</h1>
        </div>
        
        <AdBlock variant="reduced" format="rectangle" className="mb-8 !px-0 opacity-90" />
        
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-6">
          {viewAllConfig.items.map(renderMovieCard)}
        </div>
      </div>
    );
  };

  const renderMovieDetail = (movie: Movie) => (
    <div className="fixed inset-0 z-[150] bg-onyx overflow-y-auto no-scrollbar pb-32 animate-in slide-in-from-right duration-300">
      <div className="relative w-full aspect-video bg-black overflow-hidden shadow-2xl">
        <video src={movie.videoUrl} className="w-full h-full object-contain" autoPlay muted loop playsInline />
        <div className="absolute top-4 left-4 flex items-center gap-2 z-20">
           <button onClick={() => setSelectedMovie(null)} className="p-2.5 bg-black/40 backdrop-blur-xl rounded-full text-white border border-white/10 active:scale-90 transition-all">
             <ChevronLeft className="w-5 h-5" />
           </button>
        </div>
        <div className="absolute inset-0 bg-gradient-to-t from-onyx via-transparent to-transparent pointer-events-none" />
      </div>

      <div className="px-6 py-4 space-y-6 max-w-2xl mx-auto w-full">
        <div>
          <div className="flex items-center justify-between group cursor-pointer">
             <h1 className="text-xl md:text-2xl font-bold text-white tracking-tight">{movie.title}</h1>
             <div className="flex items-center text-gray-500 text-[10px] font-bold">Info <ChevronRight className="w-3 h-3 ml-1" /></div>
          </div>
          <div className="flex flex-wrap items-center gap-3 mt-2 text-[10px] text-gray-500 font-bold">
             <span className="p-0.5 bg-charcoal rounded text-[8px] text-white">4K</span>
             <span className="flex items-center gap-1">| <Star className="w-3 h-3 text-gold fill-gold" /> <span className="text-gold">{movie.rating}</span></span>
             <span>| {movie.year}</span>
             <span>| {movie.country || 'USA'}</span>
             <span>| {movie.genres[0]}</span>
          </div>
        </div>

        <div className="flex items-center gap-3 overflow-x-auto no-scrollbar py-1">
           <button onClick={() => toggleFavorite(movie.id)} className={`flex items-center gap-2 px-5 py-3 rounded-2xl border text-[10px] font-bold uppercase whitespace-nowrap transition-all active:scale-95 ${currentUser?.favorites?.includes(movie.id) ? 'bg-gold text-black border-gold' : 'bg-charcoal/40 border-white/10 text-white'}`}>
              <ListPlus className="w-4 h-4" /> Add to list
           </button>
           <button className="flex items-center gap-2 px-5 py-3 rounded-2xl bg-charcoal/40 border border-white/10 text-white text-[10px] font-bold uppercase whitespace-nowrap active:scale-95">
              <Share2 className="w-4 h-4" /> Share
           </button>
           <button onClick={() => initiateDownloadFlow(movie)} className="flex items-center gap-2 px-5 py-3 rounded-2xl bg-charcoal/40 border border-white/10 text-white text-[10px] font-bold uppercase whitespace-nowrap active:scale-95">
              <DownloadIcon className="w-4 h-4" /> Download
           </button>
           <button onClick={() => handlePlayMaster(movie)} className="flex items-center gap-2 px-5 py-3 rounded-2xl bg-charcoal/40 border border-white/10 text-white text-[10px] font-bold uppercase whitespace-nowrap active:scale-95">
              <Eye className="w-4 h-4" /> Watch
           </button>
        </div>

        {movie.category === 'Series' && movie.episodes && movie.episodes.length > 0 && (
          <section className="space-y-4 animate-in fade-in duration-500">
             <h3 className="text-base font-bold text-white uppercase tracking-tight">Episodes</h3>
             <div className="grid gap-3">
                {movie.episodes.map((ep, idx) => (
                  <button 
                    key={ep.id} 
                    onClick={() => setPlayingMovie({ title: ep.title, videoUrl: ep.videoUrl })}
                    className="flex items-center justify-between p-4 bg-charcoal/40 border border-white/5 rounded-2xl hover:border-gold/30 hover:bg-gold/5 transition-all text-left group"
                  >
                     <div className="flex items-center gap-4">
                        <span className="text-[10px] font-black text-gray-600 group-hover:text-gold">{idx + 1}</span>
                        <span className="text-xs font-bold text-white uppercase tracking-wider">{ep.title}</span>
                     </div>
                     <Play className="w-4 h-4 text-gray-600 group-hover:text-gold" />
                  </button>
                ))}
             </div>
          </section>
        )}

        <section>
           <h3 className="text-base font-bold text-white mb-2 uppercase tracking-tight">Summary</h3>
           <p className="text-gray-500 text-xs leading-relaxed font-medium">{movie.description}</p>
        </section>

        <section>
           <h3 className="text-base font-bold text-white mb-4 uppercase tracking-tight">Cast</h3>
           <div className="flex gap-4 overflow-x-auto no-scrollbar pb-6">
              {(movie.starring || []).map((star, i) => (
                <div key={i} className="flex-shrink-0 w-32 group cursor-pointer">
                   <div className="relative aspect-[4/5] rounded-xl overflow-hidden border border-white/10 mb-2 group-hover:border-gold/40 transition-all shadow-xl">
                      <img src={star.image || `https://api.dicebear.com/7.x/avataaars/svg?seed=${star.name}`} className="w-full h-full object-cover" alt={star.name} />
                   </div>
                   <h4 className="text-[10px] font-bold text-white truncate leading-tight">{star.name}</h4>
                   <p className="text-[9px] text-gray-600 font-bold truncate mt-0.5">{star.character}</p>
                </div>
              ))}
           </div>
        </section>
      </div>
    </div>
  );

  const renderDownloads = () => (
    <div className="max-w-4xl mx-auto px-6 pt-12 pb-24 h-[calc(100vh-120px)] flex flex-col animate-in fade-in duration-500 overflow-hidden">
      <div className="flex items-center gap-4 mb-8">
         <div className="w-12 h-12 bg-gold/10 rounded-2xl flex items-center justify-center border border-gold/20"><DownloadIcon className="w-6 h-6 text-gold" /></div>
         <h1 className="text-3xl font-luxury font-bold gold-text-gradient uppercase tracking-tight">Downloads</h1>
      </div>

      <div className="flex bg-charcoal/60 backdrop-blur-xl rounded-[1.5rem] p-1.5 mb-8 border border-white/5 shadow-2xl overflow-x-auto no-scrollbar">
         <button onClick={() => setAssetTab('library')} className={`flex-1 min-w-[120px] py-3 text-[9px] font-black uppercase tracking-widest rounded-xl transition-all ${assetTab === 'library' ? 'bg-gold text-black shadow-lg shadow-gold/10' : 'text-gray-500 hover:text-white'}`}>Library</button>
         <button onClick={() => setAssetTab('queue')} className={`flex-1 min-w-[120px] py-3 text-[9px] font-black uppercase tracking-widest rounded-xl transition-all ${assetTab === 'queue' ? 'bg-gold text-black shadow-lg shadow-gold/10' : 'text-gray-500 hover:text-white'}`}>Active Sync</button>
         <button onClick={() => setAssetTab('local')} className={`flex-1 min-w-[120px] py-3 text-[9px] font-black uppercase tracking-widest rounded-xl transition-all ${assetTab === 'local' ? 'bg-gold text-black shadow-lg shadow-gold/10' : 'text-gray-500 hover:text-white'}`}>Device Grid</button>
         <button onClick={() => setAssetTab('favorites')} className={`flex-1 min-w-[120px] py-3 text-[9px] font-black uppercase tracking-widest rounded-xl transition-all ${assetTab === 'favorites' ? 'bg-gold text-black shadow-lg shadow-gold/10' : 'text-gray-500 hover:text-white'}`}>Watchlist</button>
      </div>

      <div className="flex-1 overflow-y-auto no-scrollbar space-y-6">
        {assetTab === 'library' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
             {localFiles.map(file => (
               <div key={file.id} onMouseDown={() => { longPressTimer.current = window.setTimeout(() => setLongPressedFile(file), 600); }} onMouseUp={() => clearTimeout(longPressTimer.current)} className="bg-charcoal/40 p-5 rounded-3xl flex items-center justify-between border border-white/5 hover:border-gold/30 transition-all group active:scale-[0.98] cursor-pointer" onClick={() => handlePlayLocalFile(file)}>
                  <div className="flex items-center gap-5">
                    <div className="w-12 h-12 bg-gold/10 rounded-2xl flex items-center justify-center group-hover:bg-gold group-hover:text-black transition-all"><Play className="w-5 h-5 fill-current" /></div>
                    <div>
                      <h4 className="text-xs font-black text-white uppercase tracking-wider line-clamp-1">{file.name}</h4>
                      <p className="text-[9px] text-gray-600 font-bold mt-1 uppercase tracking-widest">Master Asset Node</p>
                    </div>
                  </div>
                  <Check className="w-4 h-4 text-gold opacity-40" />
               </div>
             ))}
             {localFiles.length === 0 && <div className="col-span-full text-center py-24 border border-dashed border-white/10 rounded-[3rem] text-gray-700 font-black uppercase text-[10px] tracking-[0.5em] flex flex-col items-center gap-4"><HardDrive className="w-8 h-8" /> No Assets Stored</div>}
          </div>
        )}

        {assetTab === 'queue' && (
          <div className="space-y-4">
             {downloads.filter(d => d.status === 'downloading').map(dl => (
               <div key={dl.id} className="bg-charcoal/40 border border-white/5 p-5 rounded-3xl flex gap-6 group hover:border-gold/20 transition-all">
                  <div className="relative w-20 h-28 shrink-0 rounded-2xl overflow-hidden border border-white/10 shadow-xl">
                    <img src={dl.thumbnail} className="w-full h-full object-cover" alt="" />
                    <div className="absolute inset-0 bg-black/40 flex items-center justify-center"><Loader2 className="w-8 h-8 text-gold animate-spin" /></div>
                  </div>
                  <div className="flex-1 py-2 flex flex-col justify-center">
                     <h3 className="font-bold text-xs text-white uppercase tracking-widest mb-4 line-clamp-1">{dl.title}</h3>
                     <div className="h-2 w-full bg-black rounded-full overflow-hidden mb-3"><div className="h-full bg-gold shadow-[0_0_10px_rgba(212,175,55,0.4)] transition-all duration-500" style={{ width: `${dl.progress}%` }} /></div>
                     <div className="flex justify-between items-center">
                        <p className="text-[9px] text-gold font-black uppercase tracking-[0.2em]">{Math.floor(dl.progress)}% Synchronizing</p>
                        <p className="text-[8px] text-gray-600 font-black uppercase">{dl.size}</p>
                     </div>
                  </div>
               </div>
             ))}
             {downloads.filter(d => d.status === 'downloading').length === 0 && <div className="text-center py-24 border border-dashed border-white/10 rounded-[3rem] text-gray-700 font-black uppercase text-[10px] tracking-[0.5em] flex flex-col items-center gap-4"><Timer className="w-8 h-8" /> Queue is Empty</div>}
          </div>
        )}

        {assetTab === 'local' && (
          <div className="space-y-6">
             <div className="bg-charcoal/40 border border-gold/10 border-dashed rounded-[2.5rem] p-12 text-center flex flex-col items-center gap-6 group cursor-pointer hover:bg-gold/5 transition-all" onClick={() => localFileInputRef.current?.click()}>
                <div className="w-16 h-16 gold-gradient rounded-3xl flex items-center justify-center shadow-2xl shadow-gold/20 group-hover:scale-110 transition-transform"><FileVideo className="w-8 h-8 text-black" /></div>
                <div className="space-y-2">
                   <h3 className="text-lg font-luxury font-bold text-white uppercase tracking-tighter">Authorize Device Grid</h3>
                   <p className="text-[10px] text-gray-500 font-bold uppercase tracking-[0.3em]">Map local videos to TR3NDING network</p>
                </div>
                <input type="file" ref={localFileInputRef} accept="video/*" multiple className="hidden" onChange={handlePickLocalVideos} />
                <button className="bg-gold text-black px-10 py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest active:scale-95 transition-all shadow-xl">Scan & Map Storage</button>
             </div>
             
             <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {localFiles.filter(f => f.type.includes('video')).map(file => (
                   <div key={file.id} onClick={() => handlePlayLocalFile(file)} className="bg-charcoal/40 p-5 rounded-3xl flex items-center justify-between border border-white/5 hover:border-gold/30 transition-all cursor-pointer">
                      <div className="flex items-center gap-4">
                         <Play className="w-4 h-4 text-gold fill-current" />
                         <span className="text-[10px] font-bold text-white uppercase truncate max-w-[180px]">{file.name}</span>
                      </div>
                      <span className="text-[8px] text-gray-600 font-black uppercase">Device Node</span>
                   </div>
                ))}
             </div>
          </div>
        )}

        {assetTab === 'favorites' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
             {movies.filter(m => currentUser?.favorites?.includes(m.id)).map(movie => (
               <div key={movie.id} onClick={() => setSelectedMovie(movie)} className="bg-charcoal/30 rounded-3xl overflow-hidden border border-white/5 p-4 flex gap-4 hover:border-gold/30 transition-all cursor-pointer">
                  <img src={movie.thumbnail} className="w-20 h-28 object-cover rounded-2xl" alt="" />
                  <div className="flex-1 py-2 flex flex-col justify-between">
                     <h4 className="text-xs font-black text-white uppercase tracking-wide line-clamp-2">{movie.title}</h4>
                     <span className="text-[8px] w-fit bg-gold/10 text-gold border border-gold/20 px-3 py-1 rounded-full font-bold uppercase">Ready to Sync</span>
                  </div>
               </div>
             ))}
             {movies.filter(m => currentUser?.favorites?.includes(m.id)).length === 0 && <div className="col-span-full text-center py-24 border border-dashed border-white/10 rounded-[3rem] text-gray-700 font-black uppercase text-[10px] tracking-[0.5em] flex flex-col items-center gap-4"><Heart className="w-8 h-8" /> Watchlist is Empty</div>}
          </div>
        )}
      </div>

      <div className="mt-8">
         <AdBlock variant="reduced" format="rectangle" className="opacity-90 shadow-2xl h-24 sm:h-32" />
         <p className="text-[7px] text-center mt-3 text-gray-700 font-black uppercase tracking-[1em]">Sponsored Node • Get Ad-Free ></p>
      </div>

      {longPressedFile && (
        <div className="fixed inset-0 z-[400] bg-black/95 backdrop-blur-xl flex items-end justify-center p-6" onClick={() => setLongPressedFile(null)}>
           <div className="w-full max-sm bg-charcoal border border-gold/20 rounded-[3rem] p-10 animate-in slide-in-from-bottom-10" onClick={e => e.stopPropagation()}>
              <div className="w-16 h-16 gold-gradient rounded-3xl flex items-center justify-center mx-auto mb-8 shadow-2xl shadow-gold/20"><HardDrive className="w-8 h-8 text-black" /></div>
              <h3 className="text-center font-luxury font-bold text-white uppercase mb-10 tracking-widest truncate">{longPressedFile.name}</h3>
              <div className="space-y-4">
                 <button onClick={() => { LocalStorageService.removeLocalFile(longPressedFile.id); setLocalFiles(LocalStorageService.getLocalFiles()); setLongPressedFile(null); }} className="w-full p-5 bg-red-500/10 text-red-500 border border-red-500/20 rounded-2xl text-[10px] font-black uppercase tracking-widest flex items-center justify-between hover:bg-red-500 hover:text-white transition-all"><span>Wipe Local Data</span> <Trash2 className="w-4 h-4" /></button>
              </div>
           </div>
        </div>
      )}
    </div>
  );

  const renderSettings = () => {
    if (!currentUser) return null;
    return (
      <div className="fixed inset-0 z-[200] bg-onyx flex flex-col animate-in slide-in-from-bottom duration-300">
         <div className="px-6 py-6 flex items-center justify-between border-b border-white/5">
            <button onClick={() => setIsSettingsOpen(false)} className="p-2 text-white/60 hover:text-white transition-colors">
               <ChevronLeft className="w-7 h-7" />
            </button>
            <h1 className="text-lg font-bold text-white tracking-tight">Settings</h1>
            <button onClick={handleSaveSettings} className="px-4 py-2 text-[#4ADE80] font-bold text-base hover:opacity-80 transition-all">
               Done
            </button>
         </div>

         <div className="flex-1 overflow-y-auto no-scrollbar px-6 pt-12 pb-24">
            <div className="flex flex-col items-center mb-12">
               <div className="relative mb-6 cursor-pointer group" onClick={() => avatarInputRef.current?.click()}>
                  <img 
                    src={settingsData.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${settingsData.name}`} 
                    className="w-32 h-32 rounded-full border-2 border-white/10 p-1 bg-black shadow-2xl transition-transform group-hover:scale-105 object-cover" 
                    alt="Profile" 
                  />
                  <div className="absolute bottom-0 right-0 w-9 h-9 bg-white rounded-full flex items-center justify-center border-2 border-onyx shadow-lg group-hover:bg-gold transition-colors">
                     <Camera className="w-5 h-5 text-black" />
                  </div>
                  <input type="file" ref={avatarInputRef} className="hidden" accept="image/*" onChange={handleAvatarChange} />
               </div>
               <h2 
                className="text-2xl font-bold text-white tracking-tight cursor-pointer hover:text-gold transition-colors"
                onClick={() => {
                  const newName = prompt("Enter new Display Name:", settingsData.name);
                  if (newName) setSettingsData(prev => ({ ...prev, name: newName }));
                }}
               >
                 {settingsData.name}
               </h2>
            </div>

            <div className="space-y-2">
               {[
                 { label: 'Password', key: 'passwordSet', value: settingsData.passwordSet ? 'Active' : 'Not set' },
                 { label: 'Username', key: 'username', value: settingsData.username || 'Not set' },
                 { label: 'Email', key: 'email', value: settingsData.email },
                 { label: 'Phone nº', key: 'phone', value: settingsData.phone || 'Not set' }
               ].map((item) => (
                 <button 
                   key={item.label}
                   onClick={() => {
                     const currentVal = settingsData[item.key as keyof User];
                     const promptText = item.key === 'passwordSet' ? 'Enter new password (this will set password as Active):' : `Enter new ${item.label}:`;
                     const newVal = prompt(promptText, typeof currentVal === 'string' ? currentVal : '');
                     if (newVal !== null) {
                        setSettingsData(prev => ({ 
                           ...prev, 
                           [item.key]: item.key === 'passwordSet' ? true : (newVal === '' ? undefined : newVal)
                        }));
                     }
                   }}
                   className="w-full flex items-center justify-between py-6 group border-b border-white/5 last:border-0"
                 >
                    <span className="text-lg font-medium text-white/90">{item.label}</span>
                    <div className="flex items-center gap-3">
                       <span className="text-lg text-gray-500 font-medium truncate max-w-[150px]">{item.value}</span>
                       <ChevronRight className="w-5 h-5 text-gray-700 group-active:translate-x-1 transition-transform" />
                    </div>
                 </button>
               ))}
            </div>
         </div>
      </div>
    );
  };

  const renderAuth = () => {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center px-6 relative overflow-hidden bg-black">
         <div className="absolute top-[-10%] left-[-10%] w-[50%] aspect-square bg-gold/5 rounded-full blur-[120px] animate-pulse" />
         <div className="absolute bottom-[-10%] right-[-10%] w-[50%] aspect-square bg-gold/5 rounded-full blur-[120px] animate-pulse delay-700" />
         
         <div className="w-full max-w-lg relative z-10 animate-in fade-in slide-in-from-bottom-12 duration-700">
            <div className="text-center mb-12">
               <div className="w-20 h-20 gold-gradient rounded-3xl rotate-45 flex items-center justify-center shadow-2xl shadow-gold/20 mx-auto mb-8">
                  <Play className="w-10 h-10 text-black -rotate-45 ml-1.5" />
               </div>
               <h1 className="text-4xl md:text-5xl font-luxury font-bold gold-text-gradient uppercase tracking-tighter mb-2">TR3NDING BLOCK</h1>
               <p className="text-[10px] text-gray-500 font-black uppercase tracking-[0.5em] opacity-80">The Elite Streaming Protocol</p>
            </div>

            <div className="bg-charcoal/40 backdrop-blur-3xl border border-white/5 rounded-[3.5rem] p-10 md:p-14 shadow-2xl relative overflow-hidden">
               <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-gold/40 to-transparent" />
               
               <div className="flex bg-black/40 rounded-2xl p-1.5 mb-10 border border-white/5">
                  <button 
                    onClick={() => setAuthMode('login')}
                    className={`flex-1 py-4 text-[9px] font-black uppercase tracking-widest rounded-xl transition-all ${authMode === 'login' ? 'bg-gold text-black shadow-lg shadow-gold/10' : 'text-gray-500 hover:text-white'}`}
                  >
                    Authorize Identity
                  </button>
                  <button 
                    onClick={() => setAuthMode('register')}
                    className={`flex-1 py-4 text-[9px] font-black uppercase tracking-widest rounded-xl transition-all ${authMode === 'register' ? 'bg-gold text-black shadow-lg shadow-gold/10' : 'text-gray-500 hover:text-white'}`}
                  >
                    Join The Grid
                  </button>
               </div>

               <div className="space-y-6">
                  {authMode === 'register' && (
                    <div className="space-y-2 animate-in slide-in-from-left-4 duration-300">
                       <label className="text-[8px] text-gold font-black uppercase tracking-widest ml-4">Full Name</label>
                       <div className="relative group">
                          <UserIcon className="absolute left-6 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-600 group-focus-within:text-gold transition-colors" />
                          <input 
                            placeholder="JOHN DOE" 
                            className="w-full bg-black/40 p-5 pl-14 rounded-2xl border border-white/10 font-black uppercase text-[10px] tracking-widest text-white focus:border-gold/40 outline-none transition-all" 
                            value={authName} 
                            onChange={(e) => setAuthName(e.target.value)} 
                          />
                       </div>
                    </div>
                  )}

                  <div className="space-y-2 animate-in slide-in-from-right-4 duration-300">
                     <label className="text-[8px] text-gold font-black uppercase tracking-widest ml-4">Identifier Node (Email)</label>
                     <div className="relative group">
                        <Mail className="absolute left-6 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-600 group-focus-within:text-gold transition-colors" />
                        <input 
                          placeholder="ELITE@PROTOCOL.COM" 
                          className="w-full bg-black/40 p-5 pl-14 rounded-2xl border border-white/10 font-black uppercase text-[10px] tracking-widest text-white focus:border-gold/40 outline-none transition-all" 
                          value={authEmail} 
                          onChange={(e) => setAuthEmail(e.target.value)} 
                        />
                     </div>
                  </div>

                  <div className="pt-6">
                     <button 
                        onClick={handleAuth} 
                        className="w-full gold-gradient py-6 rounded-2xl font-black text-black uppercase tracking-[0.4em] text-[10px] shadow-2xl shadow-gold/20 active:scale-95 transition-all flex items-center justify-center gap-3"
                     >
                        {authMode === 'login' ? <Key className="w-4 h-4" /> : <UserCheck className="w-4 h-4" />}
                        {authMode === 'login' ? 'Sync Identity' : 'Establish Link'}
                     </button>
                  </div>
               </div>
            </div>
         </div>
      </div>
    );
  };

  const renderProfile = () => {
    if (!currentUser) return renderAuth();
    return (
      <div className="max-w-4xl mx-auto px-6 pt-4 pb-24 animate-in fade-in duration-500">
        <div className="flex justify-end items-center gap-5 mb-8">
           <button className="p-2 text-gray-500 hover:text-gold transition-colors"><Scan className="w-6 h-6" /></button>
           <button className="p-2 text-gray-500 hover:text-gold transition-colors"><Bell className="w-6 h-6" /></button>
        </div>

        <div className="bg-charcoal/40 border border-white/5 rounded-[2.5rem] p-8 md:p-12 mb-10 flex items-center gap-8 shadow-2xl">
           <div className="relative">
              <img src={currentUser.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${currentUser.name}`} className="w-24 h-24 rounded-full border-2 border-gold/40 p-1 bg-black shadow-xl object-cover" alt="" />
              <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-gold rounded-full flex items-center justify-center border-2 border-charcoal shadow-lg">
                 <Check className="w-3 h-3 text-black font-black" />
              </div>
           </div>
           <div>
              <h2 className="text-2xl font-luxury font-bold text-white uppercase tracking-tight mb-1">{currentUser.name}</h2>
              <p className="text-[10px] text-gray-500 font-black uppercase tracking-widest">ID:{currentUser.id.padStart(10, '490')}</p>
           </div>
        </div>

        <div className="bg-charcoal/40 border border-white/5 rounded-[2.5rem] p-10 mb-8 shadow-xl">
           <div className="grid grid-cols-3 gap-8">
              <button onClick={() => setAssetTab('favorites')} className="flex flex-col items-center gap-4 group">
                 <div className="w-14 h-14 bg-white/5 rounded-full flex items-center justify-center border border-white/10 group-hover:bg-gold group-hover:text-black transition-all shadow-xl">
                    <Star className="w-6 h-6" />
                 </div>
                 <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Favorites</span>
              </button>
              <button onClick={() => alert("History Protocol Encrypted")} className="flex flex-col items-center gap-4 group">
                 <div className="w-14 h-14 bg-white/5 rounded-full flex items-center justify-center border border-white/10 group-hover:bg-gold group-hover:text-black transition-all shadow-xl">
                    <Clock className="w-6 h-6" />
                 </div>
                 <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">History</span>
              </button>
              <button onClick={() => setActiveTab('downloads')} className="flex flex-col items-center gap-4 group">
                 <div className="w-14 h-14 bg-white/5 rounded-full flex items-center justify-center border border-white/10 group-hover:bg-gold group-hover:text-black transition-all shadow-xl">
                    <DownloadIcon className="w-6 h-6" />
                 </div>
                 <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Download</span>
              </button>
           </div>
        </div>

        <div className="bg-charcoal/40 border border-white/5 rounded-[2.5rem] p-10 shadow-xl overflow-hidden relative">
           <h3 className="text-base font-bold text-white mb-10 tracking-tight">Other Functions</h3>
           <div className="grid grid-cols-4 gap-y-10">
              <button className="flex flex-col items-center gap-3 group">
                 <UserIcon className="w-6 h-6 text-gray-500 group-hover:text-gold transition-colors" />
                 <span className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">Account</span>
              </button>
              <button className="flex flex-col items-center gap-3 group">
                 <Languages className="w-6 h-6 text-gray-500 group-hover:text-gold transition-colors" />
                 <span className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">Language</span>
              </button>
              <button className="flex flex-col items-center gap-3 group">
                 <CircleHelp className="w-6 h-6 text-gray-500 group-hover:text-gold transition-colors" />
                 <span className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">Feedback</span>
              </button>
              <button className="flex flex-col items-center gap-3 group">
                 <Share2 className="w-6 h-6 text-gray-500 group-hover:text-gold transition-colors" />
                 <span className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">Share</span>
              </button>
              
              <button onClick={openSettings} className="flex flex-col items-center gap-3 group relative">
                 <div className="relative">
                    <Settings className="w-6 h-6 text-gray-500 group-hover:text-gold transition-colors" />
                    <div className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-charcoal animate-pulse shadow-lg" />
                 </div>
                 <span className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">Settings</span>
              </button>

              {(currentUser.role === 'ADMIN' || currentUser.role === 'MAIN_ADMIN') && (
                 <button onClick={() => setActiveTab('admin')} className="flex flex-col items-center gap-3 group">
                    <Shield className="w-6 h-6 text-gold animate-pulse" />
                    <span className="text-[10px] font-bold text-gold uppercase tracking-widest">Console</span>
                 </button>
              )}
              <button onClick={handleLogout} className="flex flex-col items-center gap-3 group">
                 <LogOut className="w-6 h-6 text-red-500/60 group-hover:text-red-500 transition-colors" />
                 <span className="text-[10px] font-bold text-red-500/60 uppercase tracking-widest">Exit</span>
              </button>
           </div>
        </div>
      </div>
    );
  };

  const renderCategories = () => {
    const categories = [
      { id: 'Movie', title: 'MOVIES', sub: 'The Master Collection', icon: <Film className="w-12 h-12" />, img: 'https://images.unsplash.com/photo-1485846234645-a62644f84728?auto=format&fit=crop&q=80&w=800' },
      { id: 'Series', title: 'SERIES', sub: 'High Fidelity Streams', icon: <Tv className="w-12 h-12" />, img: 'https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?auto=format&fit=crop&q=80&w=800' },
      { id: 'Anime', title: 'ANIME', sub: 'Legendary Art Nodes', icon: <Zap className="w-12 h-12" />, img: 'https://images.unsplash.com/photo-1578632292335-df3abbb0d586?auto=format&fit=crop&q=80&w=800' },
    ];
    return (
      <div className="max-w-4xl mx-auto px-6 pt-16 pb-24 space-y-8 animate-in fade-in duration-500">
        <h1 className="text-4xl font-luxury font-bold text-center mb-12 uppercase tracking-tighter gold-text-gradient">Categories</h1>
        {categories.map(cat => (
          <div 
            key={cat.id} 
            onClick={() => {
              if (cat.id === 'Anime') {
                alert("Anime Hub Coming Soon...");
              } else {
                // Functional category click - filters movies based on category label
                openViewAll(cat.title, movies.filter(m => m.category === cat.id));
              }
            }} 
            className="relative aspect-[21/9] rounded-[2.5rem] overflow-hidden cursor-pointer group shadow-2xl border border-white/5"
          >
            <img src={cat.img} className="absolute inset-0 w-full h-full object-cover transition-transform group-hover:scale-110 duration-700" alt="" />
            <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent" />
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <div className="w-16 h-12 bg-white/10 backdrop-blur-xl rounded-2xl flex items-center justify-center mb-4 border border-white/20 group-hover:bg-gold group-hover:text-black transition-all text-white">{cat.icon}</div>
              <h2 className="text-4xl font-black tracking-tighter text-white uppercase">{cat.title}</h2>
              <p className="text-[10px] text-gold font-black uppercase tracking-[0.4em] opacity-80 mt-2">{cat.sub}</p>
            </div>
          </div>
        ))}
      </div>
    );
  };

  // Movie Download UI Protocol - based on Photo 1
  const renderMovieDownload = (movie: Movie) => (
    <div className="fixed inset-0 z-[300] bg-onyx overflow-y-auto no-scrollbar pb-10 flex flex-col animate-in slide-in-from-bottom duration-300">
      {/* Reduced height ad banner for mobile/download view */}
      <div className="w-full h-32 sm:h-48 relative shrink-0 overflow-hidden bg-white">
        <img src="https://images.unsplash.com/photo-1616348436168-de43ad0db179?auto=format&fit=crop&q=80&w=1200" className="w-full h-full object-cover" alt="Ad Banner" />
        <div className="absolute top-2 left-2 flex items-center gap-2">
           <div className="bg-black/60 text-white text-[8px] font-black px-1.5 py-0.5 rounded shadow-lg">10s | Get Ad-free ></div>
        </div>
        <div className="absolute bottom-4 left-6 text-black drop-shadow-sm">
           <h4 className="text-2xl font-luxury font-black leading-tight tracking-tighter">Premium Collection</h4>
           <p className="text-[9px] font-bold opacity-80 uppercase tracking-widest">Sponsored Content Provider</p>
        </div>
        <div className="absolute top-4 right-6 text-black font-black text-xl italic tracking-tighter opacity-80">BLK-X</div>
      </div>

      <div className="flex-1 p-6 space-y-6 max-w-2xl mx-auto w-full">
        <div>
          <div className="flex items-center justify-between">
             <h1 className="text-xl font-bold text-white uppercase tracking-tight">{movie.title} <span className="text-gray-600 font-medium ml-1">Info ></span></h1>
             <button onClick={() => setMovieToDownload(null)} className="p-2 bg-white/5 rounded-full text-gray-500">
                <X className="w-5 h-5" />
             </button>
          </div>
          <div className="flex flex-wrap items-center gap-3 mt-1.5 text-[10px] text-gray-500 font-bold uppercase tracking-widest">
             <Globe className="w-3 h-3" /> | <Star className="w-3 h-3 text-gold fill-gold" /> <span className="text-gold">{movie.rating}</span> | {movie.year} | {movie.country || 'USA'} | {movie.genres[0]}
          </div>
        </div>

        <div className="flex gap-4 items-center">
           <button className="flex flex-col items-center gap-2 group">
              <div className="w-12 h-12 rounded-full border border-white/10 flex items-center justify-center bg-charcoal/40 group-hover:bg-gold transition-all"><ListPlus className="w-5 h-5" /></div>
              <span className="text-[8px] font-black uppercase text-gray-600 group-hover:text-gold transition-colors">Add to list</span>
           </button>
           <button className="flex flex-col items-center gap-2 group">
              <div className="w-12 h-12 rounded-full border border-white/10 flex items-center justify-center bg-charcoal/40 group-hover:bg-gold transition-all"><Share2 className="w-5 h-5" /></div>
              <span className="text-[8px] font-black uppercase text-gray-600 group-hover:text-gold transition-colors">Share</span>
           </button>
           <button className="flex flex-col items-center gap-2 group">
              <div className="w-12 h-12 rounded-full border border-white/10 flex items-center justify-center bg-charcoal/40 group-hover:bg-gold transition-all"><DownloadIcon className="w-5 h-5" /></div>
              <span className="text-[8px] font-black uppercase text-gray-600 group-hover:text-gold transition-colors">Download</span>
           </button>
           <button onClick={() => handlePlayMaster(movie)} className="flex flex-col items-center gap-2 group">
              <div className="w-12 h-12 rounded-full border border-white/10 flex items-center justify-center bg-charcoal/40 group-hover:bg-gold transition-all"><Eye className="w-5 h-5" /></div>
              <span className="text-[8px] font-black uppercase text-gray-600 group-hover:text-gold transition-colors">Watch</span>
           </button>
        </div>

        <div className="space-y-4">
           <div className="flex items-center gap-2">
              <h3 className="text-sm font-bold text-white uppercase">Resource</h3>
              <span className="text-[9px] text-gray-500 font-bold uppercase">Uploaded by {movie.uploader || 'Esibae'} <HelpCircle className="w-3 h-3 inline ml-1" /></span>
           </div>

           <div className="relative w-40">
              <select className="w-full bg-charcoal/60 border border-white/10 rounded-xl px-4 py-2.5 text-[10px] font-black uppercase tracking-widest text-white appearance-none">
                 <option>Original Audio</option>
                 <option>Direct Stream</option>
              </select>
              <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500 pointer-events-none" />
           </div>

           <div className="space-y-2">
              {['360P', '480P', '1080P'].map(q => (
                 <button 
                  key={q} 
                  onClick={() => confirmDownload(q)}
                  className="w-full bg-charcoal/40 border border-white/5 rounded-2xl p-5 flex items-center justify-between hover:bg-gold/5 hover:border-gold/30 transition-all group"
                 >
                    <div className="text-left">
                       <h4 className="text-xs font-black text-white uppercase tracking-widest">{q} {movie.title}</h4>
                       <p className="text-[9px] text-gray-600 font-bold mt-1 uppercase tracking-[0.2em]">{q === '360P' ? '223.8MB' : q === '480P' ? '661.7MB' : '1.6GB'} · {movie.duration || '02:17:31'}</p>
                    </div>
                    <div className="p-2 bg-white/5 rounded-xl text-green-500 group-hover:bg-green-500 group-hover:text-black transition-all">
                       <DownloadIcon className="w-4 h-4" />
                    </div>
                 </button>
              ))}
           </div>
        </div>

        <section>
           <h3 className="text-lg font-bold text-white mb-2 tracking-tight uppercase">Info</h3>
           <p className="text-gray-500 text-[10px] leading-relaxed font-medium uppercase tracking-wider">{movie.description}</p>
        </section>

        <section>
           <h3 className="text-lg font-bold text-white mb-4 tracking-tight uppercase">Starring ({movie.starring?.length || 0})</h3>
           <div className="flex gap-4 overflow-x-auto no-scrollbar pb-6">
              {(movie.starring || []).map((star, i) => (
                <div key={i} className="flex-shrink-0 w-32 group cursor-pointer">
                   <div className="relative aspect-[4/5] rounded-[1.5rem] overflow-hidden border border-white/10 mb-3 group-hover:border-gold/40 transition-all shadow-xl">
                      <img src={star.image || `https://api.dicebear.com/7.x/avataaars/svg?seed=${star.name}`} className="w-full h-full object-cover" alt={star.name} />
                   </div>
                   <h4 className="text-[10px] font-black text-white uppercase tracking-widest truncate">{star.name}</h4>
                   <p className="text-[8px] text-gray-600 font-bold uppercase tracking-widest truncate mt-0.5">{star.character}</p>
                </div>
              ))}
           </div>
        </section>
      </div>
    </div>
  );

  // Series Download UI Protocol - based on Photo 2
  const renderSeriesDownload = (movie: Movie) => (
    <div className="fixed inset-0 z-[300] bg-onyx overflow-y-auto no-scrollbar pb-10 flex flex-col animate-in slide-in-from-bottom duration-300">
      <div className="w-full h-32 sm:h-48 relative shrink-0 overflow-hidden bg-white">
        <img src="https://images.unsplash.com/photo-1626814026160-2237a95fc5a0?auto=format&fit=crop&q=80&w=1200" className="w-full h-full object-cover" alt="Ad Banner" />
        <div className="absolute top-2 left-2 flex items-center gap-2">
           <div className="bg-black/60 text-white text-[8px] font-black px-1.5 py-0.5 rounded shadow-lg">4s | Get Ad-free ></div>
        </div>
        <div className="absolute bottom-4 left-6 text-black drop-shadow-sm">
           <h4 className="text-2xl font-luxury font-black leading-tight tracking-tighter">Premium Collection</h4>
           <p className="text-[9px] font-bold opacity-80 uppercase tracking-widest">Sponsored Provider</p>
        </div>
        <div className="absolute top-4 right-6 text-black font-black text-xl italic tracking-tighter opacity-80">A100C</div>
      </div>

      <div className="flex-1 p-6 space-y-8 max-w-2xl mx-auto w-full">
        <div className="flex items-center justify-between border-b border-white/5 pb-6">
           <h2 className="text-xl font-bold text-white uppercase tracking-tight">Download</h2>
           <button onClick={() => setMovieToDownload(null)} className="p-2 bg-white/5 rounded-full text-gray-500">
              <X className="w-6 h-6" />
           </button>
        </div>

        <div className="flex flex-col gap-4">
           <div className="flex items-center gap-2">
              <h3 className="text-base font-bold text-white uppercase">Resources</h3>
              <span className="text-[9px] text-gray-500 font-bold uppercase">Uploaded by {movie.uploader || 'Lindiwe Veronica'}</span>
              <HelpCircle className="w-4 h-4 text-gray-600 ml-auto" />
           </div>

           <div className="flex flex-wrap items-center gap-4">
              <div className="relative">
                 <select className="bg-charcoal/60 border border-white/10 rounded-xl px-5 py-2.5 text-[10px] font-black uppercase tracking-widest text-white appearance-none min-w-[120px]">
                    <option>Season 01</option>
                 </select>
                 <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500 pointer-events-none" />
              </div>

              <div className="flex bg-charcoal/60 rounded-xl p-1 border border-white/5">
                 {['360P', '480P', '720P'].map(q => (
                    <button 
                      key={q} 
                      onClick={() => setSelectedQuality(q)}
                      className={`px-6 py-2 rounded-lg text-[9px] font-black uppercase tracking-widest transition-all ${selectedQuality === q ? 'bg-teal-500/20 text-teal-400 border border-teal-500/30' : 'text-gray-500'}`}
                    >
                      {q}
                    </button>
                 ))}
              </div>
           </div>
        </div>

        <div className="space-y-4">
           {(movie.episodes && movie.episodes.length > 0 ? movie.episodes : []).map((ep, idx) => (
              <div 
                key={ep.id} 
                onClick={() => setSelectedEpisode(ep)}
                className={`flex items-start gap-4 p-4 rounded-2xl cursor-pointer transition-all border ${selectedEpisode?.id === ep.id ? 'bg-white/5 border-gold/20' : 'border-transparent'}`}
              >
                 <div className={`w-5 h-5 rounded-full border-2 mt-0.5 shrink-0 flex items-center justify-center transition-colors ${selectedEpisode?.id === ep.id ? 'border-gold' : 'border-gray-700'}`}>
                    {selectedEpisode?.id === ep.id && <div className="w-2.5 h-2.5 bg-gold rounded-full" />}
                 </div>
                 <div className="flex-1 min-w-0">
                    <h4 className={`text-[11px] font-bold uppercase tracking-wider mb-1 ${selectedEpisode?.id === ep.id ? 'text-gold' : 'text-white'}`}>S0{ep.season || 1} E{String(idx + 1).padStart(2, '0')} · {ep.title}</h4>
                    <p className="text-[9px] text-gray-600 font-bold uppercase tracking-widest">{ep.size || '84.0MB'} | {ep.duration || '42:37'}</p>
                 </div>
              </div>
           ))}
        </div>

        <button 
          onClick={() => confirmDownload()}
          disabled={!selectedEpisode}
          className="w-full gold-gradient py-6 rounded-[2rem] font-black text-black text-[10px] uppercase tracking-[0.4em] shadow-2xl shadow-gold/20 active:scale-[0.98] transition-all flex items-center justify-center gap-3"
        >
          <DownloadIcon className="w-5 h-5" /> Sync Selection to Grid
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-onyx text-white font-sans relative overflow-x-hidden">
      {currentUser && activeTab !== 'profile' && !isSettingsOpen && (
        <header className="fixed top-0 left-0 right-0 z-50 bg-black/90 backdrop-blur-2xl px-6 py-5 border-b border-gold/10 flex items-center justify-between">
          <div className="flex items-center gap-3" onClick={() => { setActiveTab('home'); setSelectedMovie(null); setViewAllConfig(null); }}>
             <div className="w-8 h-8 gold-gradient rounded-xl rotate-45 flex items-center justify-center shadow-lg shadow-gold/10"><Play className="w-4 h-4 text-black -rotate-45 ml-0.5" /></div>
             <span className="font-luxury font-bold text-lg gold-text-gradient tracking-tighter cursor-pointer">TR3NDING BLOCK</span>
          </div>
          <div className="flex items-center gap-4">
            <Globe className="w-5 h-5 text-gray-600 hidden sm:block" />
            <button onClick={() => { setActiveTab('profile'); setSelectedMovie(null); setViewAllConfig(null); }} className="w-11 h-11 rounded-2xl border border-gold/30 bg-gold/10 p-1 flex items-center justify-center transition-all hover:scale-105 active:scale-95">
              <img src={currentUser.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${currentUser.name}`} className="w-full h-full rounded-xl object-cover" alt="" />
            </button>
          </div>
        </header>
      )}

      <main className={`${!currentUser || activeTab === 'profile' || isSettingsOpen ? 'pt-0' : 'pt-24'} min-h-screen`}>
        {!currentUser ? renderAuth() : (
          <>
            {activeTab === 'home' && renderHome()}
            {activeTab === 'view-all' && renderViewAll()}
            {activeTab === 'categories' && renderCategories()}
            {activeTab === 'downloads' && renderDownloads()}
            {activeTab === 'profile' && !isSettingsOpen && renderProfile()}
            {isSettingsOpen && renderSettings()}
            {activeTab === 'admin' && currentUser && (
              <AdminPanel currentUser={currentUser} movies={movies} onAddMovie={m => setMovies([...movies, m])} onUpdateMovie={m => setMovies(movies.map(v => v.id === m.id ? m : v))} onDeleteMovie={id => setMovies(movies.filter(m => m.id !== id))} />
            )}
          </>
        )}
      </main>

      {currentUser && (
        <nav className={`fixed bottom-0 left-0 right-0 z-[60] bg-black/95 backdrop-blur-2xl border-t border-gold/10 flex items-center justify-between px-10 py-6 transition-transform duration-300 ${isSettingsOpen ? 'translate-y-full' : 'translate-y-0'}`}>
          <button onClick={() => { setActiveTab('home'); setSelectedMovie(null); setViewAllConfig(null); }} className={`flex flex-col items-center gap-1.5 transition-all ${activeTab === 'home' && !selectedMovie ? 'text-gold scale-110' : 'text-gray-600'}`}><Home className="w-5 h-5" /><span className="text-[7px] font-black uppercase tracking-widest text-center">Home</span></button>
          <button onClick={() => { setActiveTab('categories'); setSelectedMovie(null); setViewAllConfig(null); }} className={`flex flex-col items-center gap-1.5 transition-all ${activeTab === 'categories' ? 'text-gold scale-110' : 'text-gray-600'}`}><LayoutGrid className="w-5 h-5" /><span className="text-[7px] font-black uppercase tracking-widest text-center">Categories</span></button>
          <button onClick={() => { setActiveTab('downloads'); setSelectedMovie(null); setViewAllConfig(null); }} className={`flex flex-col items-center gap-1.5 transition-all ${activeTab === 'downloads' ? 'text-gold scale-110' : 'text-gray-600'}`}><DownloadIcon className="w-5 h-5" /><span className="text-[7px] font-black uppercase tracking-widest text-center">Downloads</span></button>
          <button onClick={() => { setActiveTab('profile'); setSelectedMovie(null); setViewAllConfig(null); }} className={`flex flex-col items-center gap-1.5 transition-all ${activeTab === 'profile' ? 'text-gold scale-110' : 'text-gray-600'}`}><UserIcon className="w-5 h-5" /><span className="text-[7px] font-black uppercase tracking-widest text-center">Identity</span></button>
        </nav>
      )}

      {selectedMovie && renderMovieDetail(selectedMovie)}

      {(showAdOverlay || isDecrypting) && (
        <div className="fixed inset-0 z-[500] bg-black flex flex-col items-center justify-center p-10 text-center animate-in fade-in duration-300 overflow-hidden">
           <div className="absolute inset-0 bg-gold/5 animate-pulse" />
           <div className="max-w-md w-full relative">
              <div className="relative w-64 h-64 mx-auto mb-16">
                 <div className="absolute inset-0 border border-gold/10 rounded-full scale-[1.4] animate-[pulse_3s_infinite]" />
                 <div className="absolute inset-0 border-2 border-gold/20 rounded-full animate-[spin_8s_linear_infinite]" />
                 <div className="absolute inset-4 border-[1px] border-gold/40 rounded-full animate-[spin_4s_linear_infinite_reverse]" />
                 <div className="absolute inset-8 border-[6px] border-gold rounded-full border-t-transparent border-l-transparent animate-[spin_1.5s_cubic-bezier(0.4,0,0.2,1)_infinite]" />
                 <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-36 h-36 bg-charcoal rounded-full flex flex-col items-center justify-center border border-gold/40 shadow-[0_0_100px_rgba(212,175,55,0.3)]">
                       <Timer className="w-12 h-12 text-gold mb-1 animate-pulse" />
                       <h3 className="text-4xl font-luxury font-bold text-white tracking-tighter">{showAdOverlay ? adCountdown : "..."}</h3>
                    </div>
                 </div>
              </div>
              <div className="space-y-6">
                 <h2 className="text-xl font-luxury font-bold text-gold uppercase tracking-[0.3em] drop-shadow-lg">{adMessage}</h2>
                 <p className="text-[10px] text-gray-600 font-black uppercase tracking-[0.6em]">Secure Protocol Verified</p>
              </div>
              {showAdOverlay && <div className="mt-16 bg-charcoal/40 border border-white/5 rounded-[2.5rem] p-8 backdrop-blur-3xl shadow-2xl scale-95 border-gold/20"><AdBlock variant="reduced" format="rectangle" /></div>}
           </div>
        </div>
      )}

      {movieToDownload && (
        movieToDownload.category === 'Series' 
          ? renderSeriesDownload(movieToDownload)
          : renderMovieDownload(movieToDownload)
      )}

      {playingMovie && <MediaPlayer url={playingMovie.videoUrl} title={playingMovie.title} onClose={() => setPlayingMovie(null)} />}
    </div>
  );
};

export default App;

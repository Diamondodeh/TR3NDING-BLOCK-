
import { Movie } from './types';

export const INITIAL_MOVIES: Movie[] = [
  {
    id: '1',
    title: 'WICKED: FOR GOOD',
    description: 'Elphaba, the future Wicked Witch of the West and her relationship with Glinda, the Good Witch of the North. The second of a two-part feature film adaptation of the Broadway musical.',
    category: 'Movie',
    thumbnail: 'https://images.unsplash.com/photo-1594908900066-3f47337549d8?auto=format&fit=crop&q=80&w=800',
    videoUrl: 'http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
    rating: 6.8,
    year: 2025,
    country: 'United States',
    duration: '02:22:01',
    uploader: 'Esibae🇬🇭',
    genres: ['Drama', 'Fantasy'],
    starring: [
      { name: 'Cynthia Erivo', character: 'Elphaba', image: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Cynthia' },
      { name: 'Ariana Grande', character: 'Glinda', image: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Ariana' },
      { name: 'Jeff Goldblum', character: 'The Wizard', image: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Jeff' },
      { name: 'Michelle Yeoh', character: 'Madame Morrible', image: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Michelle' },
      { name: 'Jonathan Bailey', character: 'Fiyero', image: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Jonathan' }
    ],
    isTrending: true,
  },
  {
    id: '2',
    title: 'DUNE: PART TWO',
    description: 'Paul Atreides unites with Chani and the Fremen while on a warpath of revenge against the conspirators who destroyed his family.',
    category: 'Movie',
    thumbnail: 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&q=80&w=800',
    videoUrl: 'http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
    rating: 8.9,
    year: 2024,
    country: 'United States',
    duration: '02:46:00',
    uploader: 'Admin',
    genres: ['Action', 'Sci-Fi'],
    starring: [
      { name: 'Timothée Chalamet', character: 'Paul Atreides' },
      { name: 'Zendaya', character: 'Chani' },
      { name: 'Rebecca Ferguson', character: 'Lady Jessica' }
    ],
    isTrending: true,
  },
  {
    id: '3',
    title: 'THE LAST OF US',
    description: 'After a global pandemic destroys civilization, a hardened survivor takes charge of a 14-year-old girl who may be humanity\'s last hope.',
    category: 'Series',
    thumbnail: 'https://images.unsplash.com/photo-1626814026160-2237a95fc5a0?auto=format&fit=crop&q=80&w=800',
    videoUrl: 'http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
    rating: 8.8,
    year: 2023,
    country: 'United States',
    duration: '50:00',
    uploader: 'Node-Prime',
    genres: ['Action', 'Drama', 'Adventure'],
    starring: [
      { name: 'Pedro Pascal', character: 'Joel Miller' },
      { name: 'Bella Ramsey', character: 'Ellie' }
    ],
    isTrending: true,
  },
  {
    id: '4',
    title: 'ATTACK ON TITAN',
    description: 'Humanity is forced to live in cities surrounded by enormous walls due to the Titans, gigantic humanoid beings who eat humans seemingly without reason.',
    category: 'Anime',
    thumbnail: 'https://images.unsplash.com/photo-1578632292335-df3abbb0d586?auto=format&fit=crop&q=80&w=800',
    videoUrl: 'http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4',
    rating: 9.1,
    year: 2023,
    country: 'Japan',
    duration: '24:00',
    uploader: 'Anime-San',
    genres: ['Action', 'Fantasy', 'Horror'],
    starring: [
      { name: 'Yuki Kaji', character: 'Eren Yeager' },
      { name: 'Yui Ishikawa', character: 'Mikasa Ackerman' }
    ],
    isTrending: true,
  },
  {
    id: '5',
    title: 'CITIZEN KANE: REMASTERED',
    description: 'Following the death of publishing tycoon Charles Foster Kane, reporters scramble to uncover the meaning of his final utterance.',
    category: 'Movie',
    thumbnail: 'https://images.unsplash.com/photo-1485846234645-a62644f84728?auto=format&fit=crop&q=80&w=800',
    videoUrl: 'http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4',
    rating: 8.3,
    year: 2024,
    country: 'USA',
    duration: '01:59:00',
    uploader: 'Classic-Hub',
    genres: ['Drama', 'Mystery'],
    isTrending: false,
  }
];

export const GENRES = ['Action', 'Anime', 'Series', 'Drama', 'Sci-Fi', 'History', 'Comedy'];
export const YEARS = [2025, 2024, 2023, 2022, 2021, 2020];
export const QUALITIES = ['360P', '480P', '720P', '1080P'];
export const SPEEDS = [0.5, 0.75, 1, 1.25, 1.5, 2];

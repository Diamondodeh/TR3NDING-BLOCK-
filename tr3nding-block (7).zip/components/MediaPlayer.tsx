
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Play, Pause, RotateCcw, RotateCw, Volume2, Sun, ChevronLeft, HelpCircle, Scaling, Maximize2, Smartphone } from 'lucide-react';

interface MediaPlayerProps {
  url: string;
  onClose: () => void;
  title: string;
}

const MediaPlayer: React.FC<MediaPlayerProps> = ({ url, onClose, title }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [volume, setVolume] = useState(1);
  const [brightness, setBrightness] = useState(1);
  const [showControls, setShowControls] = useState(true);
  const [currentTimeRaw, setCurrentTimeRaw] = useState(0);
  const [durationRaw, setDurationRaw] = useState(0);
  const [isGestureActive, setIsGestureActive] = useState<'volume' | 'brightness' | null>(null);
  const [gestureValue, setGestureValue] = useState(0);

  const controlsTimeout = useRef<number | null>(null);
  const touchStartY = useRef<number>(0);

  const resetControlsTimer = useCallback(() => {
    if (controlsTimeout.current) window.clearTimeout(controlsTimeout.current);
    setShowControls(true);
    controlsTimeout.current = window.setTimeout(() => {
      setShowControls(false);
    }, 4000);
  }, []);

  useEffect(() => {
    resetControlsTimer();
    return () => { if (controlsTimeout.current) window.clearTimeout(controlsTimeout.current); };
  }, [resetControlsTimer]);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    const updateProgress = () => {
      setProgress((video.currentTime / video.duration) * 100);
      setCurrentTimeRaw(video.currentTime);
    };
    const handleLoadedMetadata = () => setDurationRaw(video.duration);
    video.addEventListener('timeupdate', updateProgress);
    video.addEventListener('loadedmetadata', handleLoadedMetadata);
    return () => {
      video.removeEventListener('timeupdate', updateProgress);
      video.removeEventListener('loadedmetadata', handleLoadedMetadata);
    };
  }, [url]);

  const formatTime = (time: number) => {
    const hours = Math.floor(time / 3600);
    const mins = Math.floor((time % 3600) / 60);
    const secs = Math.floor(time % 60);
    if (hours > 0) return `${hours.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const togglePlay = () => {
    if (videoRef.current?.paused) { videoRef.current.play(); setIsPlaying(true); }
    else { videoRef.current?.pause(); setIsPlaying(false); }
    resetControlsTimer();
  };

  const skip = (seconds: number) => {
    if (videoRef.current) {
      videoRef.current.currentTime += seconds;
      resetControlsTimer();
    }
  };

  const handleTilt = () => {
    if (!document.fullscreenElement) {
      containerRef.current?.requestFullscreen().catch(() => {});
      if (window.screen.orientation && (window.screen.orientation as any).lock) {
        (window.screen.orientation as any).lock('landscape').catch(() => {});
      }
    } else {
      document.exitFullscreen();
    }
    resetControlsTimer();
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartY.current = e.touches[0].clientY;
    const x = e.touches[0].clientX;
    const width = window.innerWidth;
    if (x < width / 3) setIsGestureActive('brightness');
    else if (x > (width * 2) / 3) setIsGestureActive('volume');
    else setIsGestureActive(null);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isGestureActive) return;
    const deltaY = touchStartY.current - e.touches[0].clientY;
    const sensitivity = 0.005;
    
    if (isGestureActive === 'volume') {
      const newVol = Math.min(1, Math.max(0, volume + deltaY * sensitivity));
      setVolume(newVol);
      if (videoRef.current) videoRef.current.volume = newVol;
      setGestureValue(Math.round(newVol * 100));
    } else if (isGestureActive === 'brightness') {
      const newBright = Math.min(1, Math.max(0.1, brightness + deltaY * sensitivity));
      setBrightness(newBright);
      setGestureValue(Math.round(newBright * 100));
    }
    touchStartY.current = e.touches[0].clientY;
    setShowControls(false); // Hide standard controls while gesturing
  };

  const handleTouchEnd = () => {
    setIsGestureActive(null);
    resetControlsTimer();
  };

  return (
    <div 
      ref={containerRef}
      className="fixed inset-0 z-[100] bg-black flex flex-col items-center justify-center font-sans overflow-hidden select-none touch-none"
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      {/* Brightness Overlay */}
      <div 
        className="absolute inset-0 pointer-events-none z-[110]" 
        style={{ backgroundColor: `rgba(0,0,0,${1 - brightness})` }} 
      />

      <div className="relative w-full h-full flex items-center justify-center">
        {/* Removed onClick={togglePlay} to satisfy user request of removing tap-to-pause */}
        <video 
          ref={videoRef} 
          src={url} 
          className="w-full h-full object-contain" 
          playsInline 
          autoPlay 
        />

        {/* Gesture HUD */}
        {isGestureActive && (
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-[150] bg-black/60 backdrop-blur-xl rounded-3xl p-8 flex flex-col items-center gap-4 border border-white/10 animate-in fade-in zoom-in duration-200">
            {isGestureActive === 'volume' ? <Volume2 className="w-10 h-10 text-gold" /> : <Sun className="w-10 h-10 text-gold" />}
            <span className="text-2xl font-black text-white">{gestureValue}%</span>
          </div>
        )}

        {/* TOP CONTROLS */}
        <div className={`absolute top-0 left-0 right-0 p-6 z-[120] transition-opacity duration-300 flex items-start justify-between bg-gradient-to-b from-black/80 to-transparent ${showControls ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
          <button onClick={onClose} className="p-2 bg-white/10 rounded-full backdrop-blur-md active:scale-90 transition-all">
            <ChevronLeft className="w-6 h-6 text-white" />
          </button>
          
          <div className="text-center flex-1 mx-4">
            <h2 className="text-white font-luxury font-bold text-sm truncate drop-shadow-lg tracking-widest uppercase">{title}</h2>
          </div>

          <button onClick={() => alert("Help Protocol")} className="p-2 bg-white/10 rounded-full backdrop-blur-md active:scale-90 transition-all">
            <HelpCircle className="w-6 h-6 text-white" />
          </button>
        </div>

        {/* CENTER CONTROLS (Play, Skip) */}
        <div className={`absolute inset-0 flex items-center justify-center gap-12 z-[120] transition-opacity duration-300 pointer-events-none ${showControls ? 'opacity-100' : 'opacity-0'}`}>
          <button onClick={(e) => { e.stopPropagation(); skip(-10); }} className="p-6 bg-black/40 backdrop-blur-md rounded-full text-white border border-white/10 pointer-events-auto active:scale-90 transition-all">
            <RotateCcw className="w-8 h-8" />
            <span className="absolute -bottom-8 left-1/2 -translate-x-1/2 text-[10px] font-black text-gold uppercase">10S</span>
          </button>
          
          <button onClick={(e) => { e.stopPropagation(); togglePlay(); }} className="w-24 h-24 bg-gold rounded-full flex items-center justify-center shadow-[0_0_50px_rgba(212,175,55,0.4)] pointer-events-auto active:scale-95 transition-all">
            {isPlaying ? <Pause className="w-12 h-12 text-black fill-current" /> : <Play className="w-12 h-12 text-black fill-current ml-2" />}
          </button>

          <button onClick={(e) => { e.stopPropagation(); skip(10); }} className="p-6 bg-black/40 backdrop-blur-md rounded-full text-white border border-white/10 pointer-events-auto active:scale-90 transition-all">
            <RotateCw className="w-8 h-8" />
            <span className="absolute -bottom-8 left-1/2 -translate-x-1/2 text-[10px] font-black text-gold uppercase">10S</span>
          </button>
        </div>

        {/* BOTTOM CONTROLS */}
        <div className={`absolute bottom-0 left-0 right-0 p-8 z-[120] transition-opacity duration-300 bg-gradient-to-t from-black/80 to-transparent flex flex-col gap-6 ${showControls ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
          
          <div className="flex flex-col gap-2">
            <div className="relative w-full h-1.5 bg-white/20 rounded-full cursor-pointer pointer-events-auto">
              <div className="absolute top-0 left-0 h-full bg-gold rounded-full" style={{ width: `${progress}%` }} />
              <input 
                type="range" min="0" max="100" value={progress} 
                onChange={(e) => {
                  const val = parseFloat(e.target.value);
                  if (videoRef.current) videoRef.current.currentTime = (val / 100) * durationRaw;
                  resetControlsTimer();
                }}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              />
            </div>
            <div className="flex justify-between items-center text-[10px] text-gray-400 font-bold tracking-widest uppercase">
              <span>{formatTime(currentTimeRaw)}</span>
              <span>{formatTime(durationRaw)}</span>
            </div>
          </div>

          <div className="flex justify-between items-center pointer-events-auto">
             <div className="flex gap-6 items-center">
                <button onClick={handleTilt} className="flex flex-col items-center gap-1 group text-white/60 hover:text-gold transition-colors">
                  <Smartphone className="w-7 h-7 rotate-90" />
                  <span className="text-[8px] font-black uppercase tracking-widest">Tilt Node</span>
                </button>
                <button className="flex flex-col items-center gap-1 group text-white/60 hover:text-gold transition-colors">
                  <Scaling className="w-7 h-7" />
                  <span className="text-[8px] font-black uppercase tracking-widest">Scale</span>
                </button>
             </div>

             <button onClick={() => videoRef.current?.requestFullscreen()} className="text-white hover:text-gold transition-all">
                <Maximize2 className="w-8 h-8" />
             </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MediaPlayer;


import React, { useState, useEffect, useRef } from 'react';
import { Movie, User, UserRole, Category, Episode, CastMember, CloudConfig } from '../types';
import AuthService from '../services/auth';
import LocalStorageService from '../services/db';
import { GENRES, YEARS } from '../constants';
import { GoogleGenAI } from "@google/genai";
import { 
  Shield, 
  Upload, 
  UserPlus, 
  LayoutGrid, 
  X, 
  Save, 
  User as UserIcon, 
  Edit2, 
  Trash2, 
  Plus, 
  Film,
  Monitor,
  Gamepad2,
  CheckCircle2,
  ChevronDown,
  FileVideo,
  Loader2,
  Check,
  PlusCircle,
  Play,
  Users,
  Sparkles,
  Camera,
  ExternalLink,
  AlertTriangle,
  FileDigit,
  Timer,
  Server,
  Cloud,
  Database,
  Activity,
  HardDrive,
  Globe,
  Settings2,
  Key
} from 'lucide-react';

interface UploadTask {
  id: string;
  name: string;
  progress: number;
  status: 'uploading' | 'completed';
}

interface AdminPanelProps {
  onAddMovie: (movie: Movie) => void;
  onUpdateMovie: (movie: Movie) => void;
  movies: Movie[];
  onDeleteMovie: (id: string) => void;
  currentUser: User;
}

const AdminPanel: React.FC<AdminPanelProps> = ({ onAddMovie, onUpdateMovie, movies, onDeleteMovie, currentUser }) => {
  const [activeTab, setActiveTab] = useState<'upload' | 'storage' | 'manage'>('upload');
  const [users, setUsers] = useState<User[]>([]);
  const [editingMovie, setEditingMovie] = useState<Movie | null>(null);
  const [backgroundUploads, setBackgroundUploads] = useState<UploadTask[]>([]);
  const [isGeneratingPhoto, setIsGeneratingPhoto] = useState(false);
  const [hasApiKey, setHasApiKey] = useState(false);
  
  const [cloudConfig, setCloudConfig] = useState<CloudConfig>(LocalStorageService.getCloudConfig());
  const [isTestingCloud, setIsTestingCloud] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);
  const episodeInputRef = useRef<HTMLInputElement>(null);
  const talentPhotoInputRef = useRef<HTMLInputElement>(null);
  
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    category: 'Movie' as Category,
    thumbnail: '',
    videoUrl: '',
    genres: [] as string[],
    year: 2024,
    episodes: [] as Episode[],
    starring: [] as CastMember[]
  });

  const [newCast, setNewCast] = useState<CastMember>({ name: '', character: '', image: '' });

  useEffect(() => {
    setUsers(AuthService.getAllUsers());
    const checkApiKey = async () => {
      // @ts-ignore
      const selected = await window.aistudio.hasSelectedApiKey();
      setHasApiKey(selected);
    };
    checkApiKey();
  }, []);

  const handleSelectKey = async () => {
    // @ts-ignore
    await window.aistudio.openSelectKey();
    setHasApiKey(true);
  };

  const handleConnectCloud = () => {
    if (!cloudConfig.bucketName || !cloudConfig.projectId) {
      alert("Please provide Project ID and Bucket Name for Cloud verification.");
      return;
    }
    setIsTestingCloud(true);
    setTimeout(() => {
      const updated = { ...cloudConfig, isConnected: true };
      setCloudConfig(updated);
      LocalStorageService.saveCloudConfig(updated);
      setIsTestingCloud(false);
      alert("Google Cloud Handshake Successful. Storage Node Active.");
    }, 2000);
  };

  const resetForm = () => {
    setFormData({
      title: '',
      description: '',
      category: 'Movie',
      thumbnail: '',
      videoUrl: '',
      genres: [],
      year: 2024,
      episodes: [],
      starring: []
    });
    setEditingMovie(null);
    setNewCast({ name: '', character: '', image: '' });
  };

  const generateCastPhoto = async () => {
    if (!newCast.name) {
      alert("Please provide Talent Name for AI identity verification.");
      return;
    }
    if (!hasApiKey) {
      handleSelectKey();
      return;
    }
    setIsGeneratingPhoto(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-3-pro-image-preview',
        contents: {
          parts: [{ text: `STRICT PROTOCOL: Generate a professional publicity headshot portrait of the actual real-world personality: ${newCast.name}. Photorealistic, white studio background, cinematic lighting.` }],
        },
        config: {
          imageConfig: { aspectRatio: "1:1", imageSize: "1K" },
          tools: [{ googleSearch: {} }]
        }
      });

      let imageUrl = '';
      if (response.candidates?.[0]?.content?.parts) {
        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData) {
            imageUrl = `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
            break;
          }
        }
      }
      if (imageUrl) setNewCast(prev => ({ ...prev, image: imageUrl }));
      else throw new Error("Cloud Node error.");
    } catch (error: any) {
      alert("Search Protocol failed. Using identity seed.");
      setNewCast(prev => ({ ...prev, image: `https://api.dicebear.com/7.x/avataaars/svg?seed=${newCast.name}` }));
    } finally {
      setIsGeneratingPhoto(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setFormData(prev => ({ ...prev, thumbnail: reader.result as string }));
      reader.readAsDataURL(file);
    }
  };

  const simulateBackgroundUpload = (movieData: any, isEdit: boolean) => {
    const id = Date.now().toString();
    const newTask: UploadTask = { id, name: movieData.title, progress: 0, status: 'uploading' };
    setBackgroundUploads(prev => [...prev, newTask]);

    let prog = 0;
    const interval = setInterval(() => {
      prog += Math.random() * 10;
      if (prog >= 100) {
        prog = 100;
        clearInterval(interval);
        setBackgroundUploads(prev => prev.map(t => t.id === id ? { ...t, progress: 100, status: 'completed' } : t));
        if (isEdit) onUpdateMovie(movieData as Movie);
        else onAddMovie(movieData as Movie);
        setTimeout(() => setBackgroundUploads(prev => prev.filter(t => t.id !== id)), 3000);
      } else {
        setBackgroundUploads(prev => prev.map(t => t.id === id ? { ...t, progress: prog } : t));
      }
    }, 800);
  };

  const handleAddEpisode = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files) {
      const newEpisodes: Episode[] = Array.from(files).map((file: any, index) => ({
        id: (Date.now() + index).toString(),
        title: file.name.replace(/\.[^/.]+$/, ""),
        videoUrl: URL.createObjectURL(file),
        season: 1,
        size: (file.size / (1024 * 1024)).toFixed(1) + "MB",
        duration: "42:00"
      }));
      setFormData(prev => ({ ...prev, episodes: [...prev.episodes, ...newEpisodes] }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.thumbnail) {
      alert("Please upload a cinematic poster.");
      return;
    }
    const movieToProcess = { 
      ...formData, 
      id: editingMovie?.id || Date.now().toString(), 
      rating: editingMovie?.rating || 5.0, 
      isTrending: editingMovie?.isTrending || false,
      uploader: currentUser.name
    };
    simulateBackgroundUpload(movieToProcess, !!editingMovie);
    resetForm();
    alert(`Pushing to ${cloudConfig.isConnected ? cloudConfig.bucketName : 'Simulated Node'}...`);
  };

  const handleEditClick = (movie: Movie) => {
    setEditingMovie(movie);
    setFormData({
      title: movie.title,
      description: movie.description,
      category: movie.category,
      thumbnail: movie.thumbnail,
      videoUrl: movie.videoUrl,
      genres: movie.genres,
      year: movie.year,
      episodes: movie.episodes || [],
      starring: movie.starring || []
    });
    setActiveTab('upload');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const renderStorageTab = () => (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
         <div className="bg-charcoal/40 border border-white/5 p-8 rounded-[2.5rem] flex flex-col gap-4">
            <div className="w-12 h-12 bg-blue-500/10 text-blue-500 rounded-2xl flex items-center justify-center border border-blue-500/20"><Cloud className="w-6 h-6" /></div>
            <div>
               <h4 className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Cloud Provider</h4>
               <p className="text-xl font-luxury font-bold text-white uppercase mt-1">Google Cloud</p>
            </div>
            <div className={`flex items-center gap-2 text-[8px] font-black uppercase tracking-widest ${cloudConfig.isConnected ? 'text-green-500' : 'text-red-500'}`}>
               <div className={`w-1.5 h-1.5 rounded-full animate-pulse ${cloudConfig.isConnected ? 'bg-green-500' : 'bg-red-500'}`} /> {cloudConfig.isConnected ? 'Node Connected' : 'Disconnected'}
            </div>
         </div>
         <div className="bg-charcoal/40 border border-white/5 p-8 rounded-[2.5rem] flex flex-col gap-4">
            <div className="w-12 h-12 bg-gold/10 text-gold rounded-2xl flex items-center justify-center border border-gold/20"><Database className="w-6 h-6" /></div>
            <div>
               <h4 className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Storage Used</h4>
               <p className="text-xl font-luxury font-bold text-white uppercase mt-1">4.2 TB / 10 TB</p>
            </div>
            <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
               <div className="h-full bg-gold" style={{ width: '42%' }} />
            </div>
         </div>
         <div className="bg-charcoal/40 border border-white/5 p-8 rounded-[2.5rem] flex flex-col gap-4">
            <div className="w-12 h-12 bg-purple-500/10 text-purple-500 rounded-2xl flex items-center justify-center border border-purple-500/20"><Activity className="w-6 h-6" /></div>
            <div>
               <h4 className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Global CDN Health</h4>
               <p className="text-xl font-luxury font-bold text-white uppercase mt-1">99.9% Uptime</p>
            </div>
            <div className="flex gap-1">
               {[1,1,1,1,1,1,1,1,1,1,1,0].map((v, i) => <div key={i} className={`h-4 w-1 rounded-full ${v ? 'bg-green-500/40' : 'bg-red-500/40'}`} />)}
            </div>
         </div>
      </div>

      <div className="bg-charcoal/30 border border-white/5 rounded-[3rem] p-10">
         <div className="flex items-center justify-between mb-8">
            <h3 className="text-lg font-luxury font-bold text-white uppercase tracking-tighter flex items-center gap-3"><Settings2 className="w-5 h-5 text-gold" /> Connection Wizard</h3>
            {cloudConfig.isConnected && <button onClick={() => setCloudConfig({...cloudConfig, isConnected: false})} className="text-[8px] font-black text-red-500 uppercase border border-red-500/20 px-4 py-2 rounded-xl">Revoke Access</button>}
         </div>

         <div className="grid md:grid-cols-2 gap-8 mb-10">
            <div className="space-y-6">
               <div>
                  <label className="block text-[8px] text-gray-600 uppercase font-black tracking-widest mb-2 ml-4">GCP Project ID</label>
                  <input className="w-full bg-black/40 border border-white/10 rounded-xl px-6 py-4 text-[10px] font-bold text-white focus:border-gold outline-none uppercase tracking-widest" placeholder="tr3nding-grid-492" value={cloudConfig.projectId} onChange={e => setCloudConfig({...cloudConfig, projectId: e.target.value})} />
               </div>
               <div>
                  <label className="block text-[8px] text-gray-600 uppercase font-black tracking-widest mb-2 ml-4">Storage Bucket Name</label>
                  <input className="w-full bg-black/40 border border-white/10 rounded-xl px-6 py-4 text-[10px] font-bold text-white focus:border-gold outline-none uppercase tracking-widest" placeholder="tr3nding-vault-master" value={cloudConfig.bucketName} onChange={e => setCloudConfig({...cloudConfig, bucketName: e.target.value})} />
               </div>
            </div>
            <div className="space-y-6">
               <div>
                  <label className="block text-[8px] text-gray-600 uppercase font-black tracking-widest mb-2 ml-4">Signed URL Endpoint (Backend)</label>
                  <input className="w-full bg-black/40 border border-white/10 rounded-xl px-6 py-4 text-[10px] font-bold text-white focus:border-gold outline-none uppercase tracking-widest" placeholder="https://api.tr3nding.io/v1/sign" value={cloudConfig.apiEndpoint} onChange={e => setCloudConfig({...cloudConfig, apiEndpoint: e.target.value})} />
               </div>
               <button onClick={handleConnectCloud} disabled={isTestingCloud} className="w-full h-[58px] mt-6 bg-gold text-black rounded-xl font-black text-[10px] uppercase tracking-[0.3em] flex items-center justify-center gap-3 shadow-2xl shadow-gold/20 active:scale-[0.98] transition-all">
                  {isTestingCloud ? <Loader2 className="w-5 h-5 animate-spin" /> : <Key className="w-5 h-5" />}
                  {cloudConfig.isConnected ? 'Update Cloud Handshake' : 'Verify Project Link'}
               </button>
            </div>
         </div>

         <div className="bg-black/40 p-6 rounded-2xl border border-white/5 flex items-center gap-4">
            <AlertTriangle className="w-6 h-6 text-yellow-500 shrink-0" />
            <p className="text-[9px] text-gray-400 font-medium uppercase tracking-wider leading-relaxed">Ensure CORS is configured on your GCS bucket. Private keys must remain on the server; the app only receives short-lived signed tokens for streaming.</p>
         </div>
      </div>

      <div className="bg-charcoal/30 border border-white/5 rounded-[3rem] p-10">
         <h3 className="text-lg font-luxury font-bold text-white uppercase tracking-tighter mb-8 flex items-center gap-3"><HardDrive className="w-5 h-5 text-gold" /> Active Storage Buckets</h3>
         <div className="space-y-4">
            {[
              { name: cloudConfig.bucketName || 'tr3nding-master-4k', size: '2.8 TB', files: 142, region: cloudConfig.region },
              { name: 'tr3nding-series-nodes', size: '1.2 TB', files: 890, region: 'europe-west2' },
              { name: 'tr3nding-assets-lowres', size: '204 GB', files: 1204, region: 'africa-south1' }
            ].map((bucket, i) => (
              <div key={i} className="flex items-center justify-between p-6 bg-black/40 rounded-2xl border border-white/5 group hover:border-gold/30 transition-all">
                 <div className="flex items-center gap-6">
                    <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-gray-500 group-hover:text-gold transition-colors"><Cloud className="w-5 h-5" /></div>
                    <div>
                       <h4 className="text-xs font-black text-white uppercase tracking-widest">{bucket.name}</h4>
                       <p className="text-[8px] text-gray-600 font-bold uppercase tracking-widest mt-1">{bucket.region} • {bucket.files} OBJECTS</p>
                    </div>
                 </div>
                 <div className="text-right">
                    <p className="text-xs font-luxury font-bold text-gold">{bucket.size}</p>
                    <button className="text-[7px] font-black text-blue-400 uppercase tracking-widest mt-1 hover:underline">Manage Bucket ></button>
                 </div>
              </div>
            ))}
         </div>
      </div>
    </div>
  );

  const renderManageTab = () => (
    <div className="space-y-6 animate-in fade-in duration-500">
       <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {movies.map(movie => (
            <div key={movie.id} className="bg-charcoal/40 border border-white/5 rounded-[2rem] overflow-hidden group hover:border-gold/20 transition-all">
               <div className="relative aspect-video">
                  <img src={movie.thumbnail} className="w-full h-full object-cover" alt="" />
                  <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-4">
                     <button onClick={() => handleEditClick(movie)} className="p-3 bg-gold text-black rounded-full hover:scale-110 transition-transform"><Edit2 className="w-5 h-5" /></button>
                     <button onClick={() => { if(confirm("Confirm asset deletion?")) onDeleteMovie(movie.id); }} className="p-3 bg-red-600 text-white rounded-full hover:scale-110 transition-transform"><Trash2 className="w-5 h-5" /></button>
                  </div>
               </div>
               <div className="p-6">
                  <h4 className="text-[10px] font-black text-white uppercase tracking-widest truncate">{movie.title}</h4>
                  <div className="flex items-center justify-between mt-3">
                     <span className="text-[8px] px-2 py-0.5 bg-white/5 text-gray-500 rounded-lg font-black uppercase">{movie.category}</span>
                     <span className="text-[8px] text-gold font-bold uppercase tracking-widest">Verified Node</span>
                  </div>
               </div>
            </div>
          ))}
       </div>
    </div>
  );

  return (
    <div className="pb-32 px-6 pt-12 min-h-screen bg-black max-w-7xl mx-auto">
      {/* Background Uploads HUD */}
      {backgroundUploads.length > 0 && (
        <div className="fixed bottom-24 right-6 z-[200] space-y-3 pointer-events-none">
          {backgroundUploads.map(task => (
            <div key={task.id} className="bg-charcoal/95 backdrop-blur-3xl border border-gold/30 p-5 rounded-[2rem] w-80 shadow-2xl animate-in slide-in-from-bottom duration-300 pointer-events-auto">
              <div className="flex justify-between items-center mb-3">
                <span className="text-[10px] font-black text-white uppercase truncate max-w-[150px]">{task.name}</span>
                {task.status === 'uploading' ? <Loader2 className="w-3.5 h-3.5 text-gold animate-spin" /> : <Check className="w-3.5 h-3.5 text-green-500" />}
              </div>
              <div className="h-1.5 w-full bg-white/10 rounded-full overflow-hidden">
                <div className="h-full bg-gold shadow-[0_0_15px_rgba(212,175,55,0.4)] transition-all duration-300" style={{ width: `${task.progress}%` }} />
              </div>
              <p className="text-[8px] text-gold font-bold uppercase mt-2 tracking-widest">{task.status === 'uploading' ? 'Injecting Node...' : 'Asset Verified'}</p>
            </div>
          ))}
        </div>
      )}

      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 gold-gradient rounded-2xl flex items-center justify-center shadow-2xl shadow-gold/20">
            <Shield className="w-8 h-8 text-black" />
          </div>
          <div>
            <h1 className="text-3xl md:text-4xl font-luxury font-bold gold-text-gradient">Control Center</h1>
            <p className="text-[10px] text-gray-500 font-black uppercase tracking-[0.4em] mt-1">Grid Oversight & Cloud Management</p>
          </div>
        </div>

        <div className="flex bg-charcoal/50 backdrop-blur-xl border border-white/5 rounded-2xl p-1.5 self-start shadow-xl">
          <button 
            onClick={() => { resetForm(); setActiveTab('upload'); }}
            className={`flex items-center gap-3 px-6 py-3 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${activeTab === 'upload' ? 'bg-gold text-black shadow-lg shadow-gold/10' : 'text-gray-500 hover:text-white'}`}
          >
            {editingMovie ? <Edit2 className="w-4 h-4" /> : <Plus className="w-4 h-4" />} 
            {editingMovie ? 'Edit Asset' : 'New Entry'}
          </button>
          <button 
            onClick={() => setActiveTab('storage')}
            className={`flex items-center gap-3 px-6 py-3 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${activeTab === 'storage' ? 'bg-gold text-black shadow-lg shadow-gold/10' : 'text-gray-500 hover:text-white'}`}
          >
            <Cloud className="w-4 h-4" /> Cloud
          </button>
          <button 
            onClick={() => setActiveTab('manage')}
            className={`flex items-center gap-3 px-6 py-3 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${activeTab === 'manage' ? 'bg-gold text-black shadow-lg shadow-gold/10' : 'text-gray-500 hover:text-white'}`}
          >
            <LayoutGrid className="w-4 h-4" /> Library
          </button>
        </div>
      </div>

      <div className="grid lg:grid-cols-1 gap-12">
        <div className="w-full">
          {activeTab === 'storage' && renderStorageTab()}
          {activeTab === 'manage' && renderManageTab()}
          {activeTab === 'upload' && (
            <div className="bg-charcoal/30 border border-white/5 rounded-[3rem] p-8 md:p-12 shadow-2xl animate-in slide-in-from-bottom-8 duration-500">
              <form onSubmit={handleSubmit} className="space-y-12">
                {!hasApiKey && (
                  <div className="bg-gold/10 border border-gold/30 p-8 rounded-[2rem] animate-pulse flex items-center gap-6">
                     <AlertTriangle className="w-10 h-10 text-gold" />
                     <div className="space-y-2">
                        <h4 className="text-xs font-black text-gold uppercase tracking-widest">Cloud Identity Protocol Disabled</h4>
                        <p className="text-[10px] text-gray-400 font-bold">Pro-tier key required for Celebrity Likeness verification via Search Grounding.</p>
                        <button type="button" onClick={handleSelectKey} className="bg-gold text-black px-6 py-2 rounded-xl text-[9px] font-black uppercase mt-2 shadow-lg">Authorize Node</button>
                     </div>
                  </div>
                )}

                <div className="grid md:grid-cols-2 gap-10">
                  <div className="space-y-8">
                    <div>
                      <label className="block text-[10px] text-gold uppercase font-black tracking-[0.3em] mb-4">Master Title</label>
                      <input 
                        required
                        className="w-full bg-black/40 border border-white/10 rounded-2xl px-6 py-4 focus:outline-none focus:border-gold transition-all text-white font-bold tracking-widest uppercase text-xs"
                        placeholder="INCEPTION..."
                        value={formData.title}
                        onChange={e => setFormData({...formData, title: e.target.value})}
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-6">
                      <div>
                        <label className="block text-[10px] text-gold uppercase font-black tracking-[0.3em] mb-4">Stream Type</label>
                        <select className="w-full bg-black/40 border border-white/10 rounded-2xl px-6 py-4 focus:border-gold text-white font-black text-[10px] uppercase tracking-widest appearance-none" value={formData.category} onChange={e => setFormData({...formData, category: e.target.value as any})}>
                          <option value="Movie">Movie</option>
                          <option value="Series">Series</option>
                          <option value="Anime">Anime</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-[10px] text-gold uppercase font-black tracking-[0.3em] mb-4">Cycle</label>
                        <select className="w-full bg-black/40 border border-white/10 rounded-2xl px-6 py-4 focus:border-gold text-white font-black text-[10px] uppercase tracking-widest appearance-none" value={formData.year} onChange={e => setFormData({...formData, year: parseInt(e.target.value)})}>
                          {YEARS.map(y => <option key={y} value={y}>{y}</option>)}
                        </select>
                      </div>
                    </div>
                  </div>

                  <div>
                    <label className="block text-[10px] text-gold uppercase font-black tracking-[0.3em] mb-4">Visual Master</label>
                    <div onClick={() => fileInputRef.current?.click()} className="relative aspect-[16/10] bg-black/60 border-2 border-dashed border-white/5 rounded-[2rem] flex flex-col items-center justify-center group cursor-pointer hover:border-gold/30 transition-all overflow-hidden">
                      {formData.thumbnail ? (
                        <>
                          <img src={formData.thumbnail} className="w-full h-full object-cover transition-transform group-hover:scale-105" alt="Preview" />
                          <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"><Plus className="w-10 h-10 text-white" /></div>
                        </>
                      ) : (
                        <div className="flex flex-col items-center gap-4 text-gray-700 group-hover:text-gold transition-colors">
                           <Upload className="w-10 h-10" />
                           <span className="text-[10px] font-black uppercase tracking-widest">Inject Poster Visual</span>
                        </div>
                      )}
                      <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleFileChange} />
                    </div>
                  </div>
                </div>

                {formData.category === 'Series' && (
                  <div className="space-y-8 bg-black/40 p-10 rounded-[2.5rem] border border-white/5">
                    <div className="flex items-center justify-between">
                       <label className="block text-[10px] text-gold uppercase font-black tracking-[0.3em]">Episode Resource Nodes</label>
                       <button type="button" onClick={() => episodeInputRef.current?.click()} className="bg-gold/10 border border-gold/20 text-gold px-6 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest flex items-center gap-3 hover:bg-gold/20 transition-all shadow-xl">
                          <PlusCircle className="w-4 h-4" /> Load Local Nodes
                       </button>
                       <input type="file" ref={episodeInputRef} className="hidden" multiple accept="video/*" onChange={handleAddEpisode} />
                    </div>
                    
                    <div className="space-y-4 max-h-[500px] overflow-y-auto no-scrollbar pr-2">
                       {formData.episodes.map((ep, idx) => (
                         <div key={ep.id} className="bg-charcoal/40 border border-white/10 rounded-[1.5rem] p-6 group hover:border-gold/30 transition-all">
                            <div className="flex items-center justify-between mb-4">
                               <div className="flex items-center gap-3">
                                  <span className="w-8 h-8 bg-gold/10 text-gold text-[10px] font-black rounded-xl flex items-center justify-center border border-gold/20">#{idx+1}</span>
                                  <input className="bg-transparent border-none text-xs font-black text-white focus:outline-none uppercase tracking-widest w-64" value={ep.title} placeholder="EPISODE NODE TITLE" onChange={e => setFormData({...formData, episodes: formData.episodes.map(item => item.id === ep.id ? {...item, title: e.target.value} : item)})} />
                               </div>
                               <button type="button" onClick={() => setFormData({...formData, episodes: formData.episodes.filter(i => i.id !== ep.id)})} className="text-red-500/30 hover:text-red-500 transition-colors p-2"><X className="w-5 h-5" /></button>
                            </div>
                         </div>
                       ))}
                    </div>
                  </div>
                )}

                <div className="space-y-8 bg-black/40 p-10 rounded-[2.5rem] border border-white/5">
                  <div className="flex justify-between items-center">
                     <label className="block text-[10px] text-gold uppercase font-black tracking-[0.3em]">Cast Protocol</label>
                     <Users className="w-5 h-5 text-gold" />
                  </div>
                  <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-4 items-end">
                    <input className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-4 text-[10px] font-bold text-white focus:border-gold outline-none uppercase tracking-widest" placeholder="TALENT NAME" value={newCast.name} onChange={e => setNewCast(prev => ({ ...prev, name: e.target.value }))} />
                    <input className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-4 text-[10px] font-bold text-white focus:border-gold outline-none uppercase tracking-widest" placeholder="CHARACTER" value={newCast.character} onChange={e => setNewCast(prev => ({ ...prev, character: e.target.value }))} />
                    <button type="button" onClick={generateCastPhoto} disabled={isGeneratingPhoto || !newCast.name} className="bg-charcoal border border-gold/40 text-gold py-4 rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-gold/10 active:scale-95 transition-all flex items-center justify-center gap-2 disabled:opacity-30">
                      {isGeneratingPhoto ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />} AI LIKENESS
                    </button>
                    <button type="button" onClick={() => setFormData(prev => ({ ...prev, starring: [...prev.starring, {...newCast, image: newCast.image || `https://api.dicebear.com/7.x/avataaars/svg?seed=${newCast.name}`}] }))} className="bg-gold text-black py-4 rounded-xl font-black text-[10px] uppercase tracking-widest hover:scale-105 active:scale-95 transition-all shadow-xl shadow-gold/10">ATTACH CAST</button>
                  </div>
                </div>

                <div className="pt-8">
                  <button type="submit" className="w-full gold-gradient py-7 rounded-[2.5rem] font-black text-black text-xs uppercase tracking-[0.4em] shadow-2xl shadow-gold/20 hover:scale-[1.01] active:scale-95 transition-all">
                    {editingMovie ? 'Commit Cloud Metadata' : 'Authenticate & Push to Cloud'}
                  </button>
                </div>
              </form>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AdminPanel;

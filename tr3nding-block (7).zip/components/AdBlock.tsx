
import React, { useEffect } from 'react';
import { DollarSign } from 'lucide-react';

interface AdBlockProps {
  slotId?: string;
  format?: 'auto' | 'fluid' | 'rectangle';
  layout?: 'in-article';
  className?: string;
  variant?: 'default' | 'reduced';
}

const AdBlock: React.FC<AdBlockProps> = ({ slotId, format = 'auto', layout, className, variant = 'default' }) => {
  useEffect(() => {
    try {
      // @ts-ignore
      (window.adsbygoogle = window.adsbygoogle || []).push({});
    } catch (e) {
      console.debug("AdSense Note: Ad blocked or not yet initialized.");
    }
  }, []);

  const minHeight = variant === 'reduced' ? '80px' : '120px';

  return (
    <div className={`my-4 px-6 overflow-hidden max-w-7xl mx-auto ${className}`}>
      <div 
        className={`relative bg-charcoal/20 border border-gold/10 rounded-[2rem] flex flex-col items-center justify-center ad-shine shadow-2xl transition-all`}
        style={{ minHeight }}
      >
        <ins className="adsbygoogle"
             style={{ display: 'block', width: '100%', minHeight }}
             data-ad-client="ca-pub-0000000000000000" 
             data-ad-slot={slotId || "0000000000"} 
             data-ad-format={format}
             data-full-width-responsive="true"
             {...(layout ? { 'data-ad-layout': layout } : {})}
        ></ins>
        
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-10">
          <div className="flex flex-col items-center">
            <DollarSign className={`${variant === 'reduced' ? 'w-6 h-6' : 'w-10 h-10'} text-gold mb-1`} />
            <span className={`${variant === 'reduced' ? 'text-[6px]' : 'text-[10px]'} font-black uppercase tracking-[0.5em] text-gold`}>Premium Node</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdBlock;

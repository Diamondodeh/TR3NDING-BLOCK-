
export type UserRole = 'USER' | 'ADMIN' | 'MAIN_ADMIN';

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  avatar?: string;
  favorites?: string[]; // Array of Movie IDs
  username?: string;
  phone?: string;
  passwordSet?: boolean;
}

export type Category = 'Movie' | 'Series' | 'Anime';

export interface CastMember {
  name: string;
  character: string;
  image?: string;
}

export interface Episode {
  id: string;
  title: string;
  videoUrl: string;
  season?: number;
  size?: string;      // e.g. "84.0MB"
  duration?: string;  // e.g. "42:37"
}

export interface Movie {
  id: string;
  title: string;
  description: string;
  category: Category;
  thumbnail: string;
  videoUrl: string;
  episodes?: Episode[]; // For Series category
  serverLinks?: string[]; 
  rating: number;
  year: number;
  genres: string[];
  starring?: CastMember[]; 
  isTrending?: boolean;
  country?: string;
  duration?: string;
  uploader?: string;
}

export interface Download {
  id: string;
  movieId: string;
  progress: number;
  status: 'downloading' | 'completed' | 'paused';
  title: string;
  thumbnail: string;
  size: string;
}

export interface LocalFile {
  id: string;
  name: string;
  url: string;
  blobUrl?: string;
  size: number;
  type: string;
  lastModified?: number;
}

export interface CloudConfig {
  bucketName: string;
  apiEndpoint: string;
  projectId: string;
  isConnected: boolean;
  region: string;
}
